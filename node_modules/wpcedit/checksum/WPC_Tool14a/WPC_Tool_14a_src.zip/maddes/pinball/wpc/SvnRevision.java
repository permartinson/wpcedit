package maddes.pinball.wpc;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 17 $
$Date: 2007-09-06 18:21:16 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

Just to implement global Subversion revision data
*/

public interface SvnRevision
{
    public final static int SVN_REV = 22;
    public final static String SVN_REVSTR = "22";
    public final static String SVN_REVDATE = "2007/09/17 12:15:32";
//  public final static long SVN_REVSTAMP = yyyymmddL;
}
