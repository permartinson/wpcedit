package maddes.pinball.wpc;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 17 $
$Date: 2007-09-06 18:21:16 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

v1.4
- adapted new symbol file organisation
- first print bank number then address

v1.3
- added symbol prefix to WPCType to use for creating symbol name
- replaced getBaseName() with createSymbolPrefix(), so all the processing for
  the complete symbol name is only done once
- use of createSymbolPrefix() on newly created instances when analysing

v1.2
- added cross reference code to analysis method
- added a flag in WPC types if they shall be included in cross references
  with corresponding getter method
  (not used yet, just to keep it similar to the normal address info type class)
- moved type description to the end of the constructor as it is the most rare used parameter
- added method to update address string of normal address info to fit WPC style
  used in constructor
- added missing getter method for WPC type
- using the hex prefix defined by the rom
- added WPC type DATA for better names for misc data (d_...)
- added additional basename getter for extended naming in analysis code
- added better naming of switch handlers in known switch handler tables
- added decimal values to comment of switch handler table's count and size

v1.1
- moved general analysing code from WPC_ROM into WPC_AddrInfo
- renamed "function call structure" (FCS) to "function pointer structure" (FPS)
  as the PS is for general purpose and can even point to data
- transformed WPC types in subclass for better compiler checks and easier compares.
- removed strucToDASMxString method, as the general strucToDASMxString in
  AddrInfo got updated and fullfills all needs

v1.0
initial version
*/

/* ToDo:
- More analysis of WPC AddrInfo:
  - SWH, SWHT, SWHTPS, etc.
- Exceptions:
  - Err... normally there are no errors to handle, except the user ;)
*/

import maddes.dasm.AddrInfo;
import maddes.dasm.Rom;
import maddes.util.Numbers;
import maddes.util.Shorts;
import maddes.util.Bytes;
import java.util.ArrayList;

class WPC_AddrInfo extends maddes.dasm.AddrInfo
{
	// ***
	// *** static class variables
	// ***
	public static enum Type
	{
		FUNCTION(0, true, "function", "f"),
		DATA(0, false, "data", "d"),
		FPS(3, false),
		DPS(3, false),
		PFPS(2, false),
		SWH(11, false, "switch handler"),
		SWHT(0, false, "switch handler table");

		private int size;
		private String prefixSymbol;
		private boolean xref;
		private String description;

		private Type(int size, boolean xref, String description, String prefixSymbol)
		{
			this.size = size;
			this.xref = xref;
			this.description = description;
			this.prefixSymbol = prefixSymbol;
		}

		private Type(int size, boolean xref, String description)
		{
			this.size = size;
			this.xref = xref;
			this.description = description;
			this.prefixSymbol = this.name().toLowerCase();
		}

		private Type(int size, boolean xref)
		{
			this.size = size;
			this.xref = xref;
			this.description = this.toString();
			this.prefixSymbol = this.name().toLowerCase();
		}

		private Type()
		{
			this(0, false);
		}

		public int getSize()
		{
			return this.size;
		}

		public boolean inXRef()
		{
			return this.xref;
		}

		public String getDescription()
		{
			return this.description;
		}

		public String getPrefixSymbol()
		{
			return this.prefixSymbol;
		}
	}

	// ***
	// *** static class "constructor"
	// ***
	static
	{
	}

	// ***
	// *** static class methods
	// ***

	// ***
	// *** object variables
	// ***
	private final WPC_AddrInfo.Type wpctype;	// for special structures

	// ***
	// *** object constructors
	// ***
	public WPC_AddrInfo(WPC_Segment seg, int relofs, String basename, int ordinal, AddrInfo.Type type, String comment, int size, WPC_AddrInfo.Type wpctype, int count)	// typical for complicated data
	{
		super(seg, relofs, basename, ordinal, type, comment, size, count);
		this.wpctype = wpctype;
//		this.updateComment();
		this.updateAddrString(seg, relofs);
	}

	public WPC_AddrInfo(WPC_Segment seg, int relofs, String basename, int ordinal, AddrInfo.Type type, String comment)	// typical for code and simple data
	{
		super(seg, relofs, basename, ordinal, type, comment);
		this.wpctype = null;
//		this.updateComment();
		this.updateAddrString(seg, relofs);
	}

	public WPC_AddrInfo(WPC_Segment seg, int relofs, AddrInfo.Type type)	// typical for unknown code and unknown data
	{
		super(seg, relofs, type);
		this.wpctype = null;
//		this.updateComment();
		this.updateAddrString(seg, relofs);
	}

	private void updateComment()
	{
		if (this.wpctype!=null)
		{
			StringBuffer thiscomment;

			thiscomment = this.getComment();
			// insert backwards, always at first index
			thiscomment.insert(0, ") ");
			thiscomment.insert(0, this.wpctype);
			thiscomment.insert(0, "(");
		}
	}

	private void updateAddrString(WPC_Segment seg, int relofs)
	{
		this.setAddrString(this.getSegment().getRom().getHexPrefix() + Numbers.toHexString((short)seg.convRelOfsToAddr(relofs)));
	}

	// ***
	// *** object setter/getter
	// ***
	@Override
	public WPC_Segment getSegment()
	{
		return (WPC_Segment)super.getSegment();
	}

	public WPC_AddrInfo.Type getWPCType()
	{
		return this.wpctype;
	}

	// ***
	// *** object methods
	// ***
	@Override
	public String toString()
	{
		return "Offset " + this.getSegment().getRom().getHexPrefix() + Numbers.toHexString((short)this.getRelOffset()) + " = (Name " + this.getName() + ", Type " + this.getType() + ", Size " + this.getSize() + ')';
	}

	@Override
	public String createSymbolPrefix()
	{
		StringBuffer result;
		AddrInfo.Type type;
		WPC_Segment seg;
		int sbank, saddr;
		WPC_AddrInfo.Type wpctype;

		result = new StringBuffer();

		wpctype = this.getWPCType();
		type = this.getType();

		seg = this.getSegment();
		sbank = seg.getId();
		saddr = seg.convRelOfsToAddr(this.getRelOffset());
		if (saddr<WPC_Rom.BANKADDR)	// can not analyse data in RAM
		{
			result.append("dynamic_");
		}

		if (wpctype != null)
		{
			switch (wpctype)
			{
/*
				case DPS:	//ToDo: different prefixes depending on target? SWHTPS_....
					...
					break;
*/
				default:
					result.append(wpctype.getPrefixSymbol());
					break;
			}
		}
		else if (type!=null)
		{
			result.append(type.getPrefixSymbol());
		}
		else
		{
			result.append("label");
		}
		if (sbank!=WPC_Rom.SYSTEMBANK && sbank!=WPC_Rom.VIRTUALBANK)
		{
			result.append("_");
			result.append(Numbers.toHexString((byte)sbank));
		}
		result.append("_");
		result.append(Numbers.toHexString((short)saddr));

		return result.toString();
	}

	protected ArrayList<WPC_AddrInfo> analyseDeeper(String step, String tbasename, AddrInfo.Type ttype, WPC_AddrInfo.Type twpctype)
	{
		if (this.wpctype==null)
		{
			return null;
		}

		ArrayList<WPC_AddrInfo> result;
		WPC_AddrInfo wpc_addrinfo;
		WPC_Segment seg, seglist[];
		WPC_Rom rom;
		int ofs, relofs, i, j;
		int maxrows;

		// source
		int sbank, saddr;
		String sbankstr, saddrstr;

		StringBuffer comment;

		// target
		int taddr, tbank;
		int tsize, tcount;
		int tbanksize, tbankaddr, tstorebank;
		String tbankstr, taddrstr, tstorebankstr;

		result = new ArrayList<WPC_AddrInfo>();

		seg = this.getSegment();
		rom = seg.getRom();
		seglist = rom.getSegList();
		comment = this.getComment();
		relofs = this.getRelOffset();

		saddr = seg.convRelOfsToAddr(relofs);
		if (saddr<WPC_Rom.BANKADDR)	// can not analyse data in RAM
		{
			return null;
		}

		sbank = seg.getId();

		saddrstr = Numbers.toHexString((short)saddr);
		sbankstr = Numbers.toHexString((byte)sbank);

		ofs = seg.convRelOfsToOfs(relofs);
		tsize = 0;
		tcount = 0;

		switch (this.wpctype)
		{
			// pointer structures
			case FPS:
			case DPS:
				if (twpctype!=null)
				{
					tsize = twpctype.getSize();
				}
				taddr = Shorts.intUnsignedValue(Bytes.getShort(rom.data, ofs));
				tbank = Bytes.intUnsignedValue(rom.data[ofs+2]);
				taddrstr = Numbers.toHexString((short)taddr);
				tbankstr = Numbers.toHexString((byte)tbank);

				comment.append("Points to ");
				if (taddr<WPC_Rom.BANKADDR)
				{
					comment.append("DYNAMIC ");
				}
				comment.append(twpctype.getDescription() + " at " + this.getSegment().getRom().getHexPrefix() + tbankstr + "/" + this.getSegment().getRom().getHexPrefix() + taddrstr);

				tstorebank = rom.checkBankAddr(tbank, taddr, comment);
				tstorebankstr = Numbers.toHexString((byte)tstorebank);
				if (tstorebank!=tbank && tbank!=WPC_Rom.VIRTUALBANK)
				{
					System.out.println(" WARNING: INACCURATE " + this.wpctype + " (" + step + ") at " + this.getSegment().getRom().getHexPrefix() + sbankstr + "/" + this.getSegment().getRom().getHexPrefix() + saddrstr + " to " + this.getSegment().getRom().getHexPrefix() + tbankstr + "/" + this.getSegment().getRom().getHexPrefix() + taddrstr + ", goes to bank " + this.getSegment().getRom().getHexPrefix() + tstorebankstr);
				}

				tstorebank = rom.checkSegmentExists(tstorebank, null);
				if (tstorebank==0)
				{
					comment.append(" (WEIRD NON-EXISTANT BANK)");
					System.out.println(" ERROR: WEIRD " + this.wpctype + " (" + step + ") at " + this.getSegment().getRom().getHexPrefix() + sbankstr + "/" + this.getSegment().getRom().getHexPrefix() + saddrstr + " to NON-EXISTANT BANK " + this.getSegment().getRom().getHexPrefix() + tstorebankstr + "/" + this.getSegment().getRom().getHexPrefix() + taddrstr);
					break;
				}

				if (tstorebank==WPC_Rom.VIRTUALBANK)
				{
					tbanksize = seglist[WPC_Rom.SYSTEMBANK].getSize();
					tbankaddr = seglist[WPC_Rom.SYSTEMBANK].getAddr();
				}
				else
				{
					tbanksize = seglist[tstorebank].getSize();
					tbankaddr = seglist[tstorebank].getAddr();
				}

				if (taddr>=WPC_Rom.BANKADDR && (taddr<tbankaddr || taddr>=(tbankaddr+tbanksize)))
				{
					comment.append(" (WEIRD NON-EXISTANT ADDRESS)");
					System.out.println(" ERROR: WEIRD " + this.wpctype + " (" + step + ") at " + this.getSegment().getRom().getHexPrefix() + sbankstr + "/" + this.getSegment().getRom().getHexPrefix() + saddrstr + " to NON-EXISTANT ADDRESS " + this.getSegment().getRom().getHexPrefix() + tstorebankstr + "/" + this.getSegment().getRom().getHexPrefix() + taddrstr);
					break;
				}

				wpc_addrinfo = new WPC_AddrInfo(seglist[tstorebank], taddr-tbankaddr, tbasename, 0, ttype, null, tsize, twpctype, tcount);
				wpc_addrinfo.addSymbolPrefix();
				wpc_addrinfo.getXRef().add(this);
				result.add(wpc_addrinfo);
				break;

			// Switch Handler
			case SWH:
				if (twpctype!=null)
				{
					tsize = twpctype.getSize();
				}
				wpc_addrinfo = new WPC_AddrInfo(seg, relofs+2, tbasename, 1, ttype, null, tsize, twpctype, tcount);
				wpc_addrinfo.addSymbolPrefix();
				wpc_addrinfo.getXRef().add(this);
				result.add(wpc_addrinfo);
				break;

			// Switch Handler table
			// ToDo: Convert to general table routine (comment "table of <wpc_type>", etc.)
			case SWHT:
				tcount = Bytes.intUnsignedValue(rom.data[ofs+1]);
				tsize = Bytes.intUnsignedValue(rom.data[ofs+2]);
				wpc_addrinfo = new WPC_AddrInfo(seg, relofs+1, "swht_" + tbasename + "_count", 1, AddrInfo.Type.BYTE, "=" + this.getSegment().getRom().getHexPrefix() + Numbers.toHexString((byte)tcount) + " =" + tcount);
				wpc_addrinfo.addSymbolPrefix();
				wpc_addrinfo = new WPC_AddrInfo(seg, relofs+2, "swht_" + tbasename + "_entrysize", 1, AddrInfo.Type.BYTE, "=" + this.getSegment().getRom().getHexPrefix() + Numbers.toHexString((byte)tsize) + " =" + tsize);
				wpc_addrinfo.addSymbolPrefix();
				// entries
				ofs+=3;
				relofs+=3;
				//
				maxrows = 8;	// fix value for WPC (see http://marvin3m.com/wpc/index2.htm#switch)
				//
				for (i=0; i<tcount; i++, ofs+=tsize, relofs+=tsize)
				{
					int row, col;
					String colstr = null;

					// transform count into Column/Row of manual
					if ( i >= 1 && i <= 8 )	// Door switches
					{
						if ( tbasename.equals("Playfield") )
						{
							colstr = "D";
						}
						else if ( tbasename.equals("Fliptronic") )
						{
							colstr = "F";
						}
					}
					if ( colstr == null )
					{
						col = (i-1) / maxrows;
						colstr = new StringBuffer().append(col).toString();
					}


					row = ((i-1) % maxrows) + 1;

					wpc_addrinfo = new WPC_AddrInfo(seg, relofs, tbasename + colstr + row, 1, ttype, null, tsize, twpctype, 0);
					wpc_addrinfo.addSymbolPrefix();
					wpc_addrinfo.getXRef().add(this);
					result.add(wpc_addrinfo);
				}
				break;

			// pointer to pointer structures
			case PFPS:
				if (twpctype!=null)
				{
					tsize = twpctype.getSize();
				}
				taddr = Shorts.intUnsignedValue(Bytes.getShort(rom.data, ofs));
				tbank = sbank;
				if (taddr<WPC_Rom.BANKADDR)
				{
					tbank = WPC_Rom.VIRTUALBANK;
				}
				else if (taddr>=WPC_Rom.SYSTEMADDR)
				{
					tbank = WPC_Rom.SYSTEMBANK;
				}
				taddrstr = Numbers.toHexString((short)taddr);
				tbankstr = Numbers.toHexString((byte)tbank);

				comment.append("Points to ");
				if (taddr<WPC_Rom.BANKADDR)
				{
					comment.append("DYNAMIC ");
				}
				comment.append(twpctype.getDescription() + " at " + this.getSegment().getRom().getHexPrefix() + tbankstr + "/" + this.getSegment().getRom().getHexPrefix() + taddrstr);

				tstorebank = tbank;
				tstorebankstr = tbankstr;

				if (tstorebank==WPC_Rom.VIRTUALBANK)
				{
					tbanksize = seglist[WPC_Rom.SYSTEMBANK].getSize();
					tbankaddr = seglist[WPC_Rom.SYSTEMBANK].getAddr();
				}
				else
				{
					tbanksize = seglist[tstorebank].getSize();
					tbankaddr = seglist[tstorebank].getAddr();
				}

				if (taddr>=WPC_Rom.BANKADDR && (taddr<tbankaddr || taddr>=(tbankaddr+tbanksize)))
				{
					comment.append(" (WEIRD DYNAMIC BANK)");
					System.out.println(" ERROR: WEIRD " + this.wpctype + " (" + step + ") at " + this.getSegment().getRom().getHexPrefix() + sbankstr + "/" + this.getSegment().getRom().getHexPrefix() + saddrstr + " to " + this.getSegment().getRom().getHexPrefix() + taddrstr + " in a DYNAMIC BANK");
					break;
				}

				wpc_addrinfo = new WPC_AddrInfo(seglist[tstorebank], taddr-tbankaddr, tbasename, 0, ttype, null, tsize, twpctype, tcount);
				wpc_addrinfo.addSymbolPrefix();
				wpc_addrinfo.getXRef().add(this);
				result.add(wpc_addrinfo);
				break;
		}

		return result;
	}
}
