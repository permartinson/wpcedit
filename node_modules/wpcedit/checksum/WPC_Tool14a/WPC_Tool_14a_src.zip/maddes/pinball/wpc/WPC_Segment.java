package maddes.pinball.wpc;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 17 $
$Date: 2007-09-06 18:21:16 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

v1.4
- adapted new file naming scheme
- adapted new symbol file organisation
- added WPC DASM Group file generation

v1.3
- re-added include commands into DASMX header, which somehow disappeared (*doh*)
- checks if there is a manual symbol file present and activate the include accordingly
- "org" defintion is now always on top of DASMx symbol file

v1.2
- added cross reference code to constructors
- using the hex prefix defined by the rom

v1.0
initial version
*/

import maddes.dasm.AddrInfo;
import maddes.dasm.Rom;
import maddes.dasm.Segment;
import maddes.util.Numbers;
import java.io.File;
import java.io.PrintWriter;

class WPC_Segment extends maddes.dasm.Segment
{
	// ***
	// *** static class variables
	// ***

	// ***
	// *** static class "constructor"
	// ***

	// ***
	// *** static class methods
	// ***
	private static String createFilenamePrefix(String prefix, int bank)
	{
		String addition;

		if (prefix==null || prefix.equals(""))
		{
			return null;
		}

		if (bank == WPC_Rom.VIRTUALBANK)
		{
			addition = "general";
		}
		else
		{
			addition = "bank" + Numbers.toHexString((byte)bank);
		}

		return prefix + "_" + addition;
	}

	private static String createFilename(String filename, String extension)
	{
		return filename + extension;
	}

	private static String createFilename(String prefix, String extension, int bank)
	{
		String filename;

		filename = WPC_Segment.createFilenamePrefix(prefix, bank);
		if (filename==null || filename.equals(""))
		{
			return null;
		}

		return WPC_Segment.createFilename(filename, extension);
	}

	// ***
	// *** object variables
	// ***

	// ***
	// *** object constructors
	// ***
	public WPC_Segment(int bank, WPC_Rom rom, int ofs, int size, int addr)
	{
		super(bank, rom, ofs, size, addr);
		this.setIdString(this.getRom().getHexPrefix() + Numbers.toHexString((byte)bank));
	}

	// ***
	// *** object setter/getter
	// ***
	@Override
	public WPC_Rom getRom()
	{
		return (WPC_Rom)super.getRom();
	}

	// ***
	// *** object methods
	// ***
	@Override
	public String toString()
	{
		return "Bank " + this.getIdString() + ": Offset " + this.getRom().getHexPrefix() + Numbers.toHexString(this.getOffset()) + ", Size " + this.getRom().getHexPrefix() + Numbers.toHexString((short)this.getSize()) + ", Address " + this.getRom().getHexPrefix() + Numbers.toHexString((short)this.getAddr());
	}

	@Override
	protected String createFilename(String extension)
	{
		String prefix;
		int bank, ofs;

		if (this.getRom()==null)
		{
			return null;
		}

		prefix = this.getRom().getFilePrefix();
		bank = this.getId();
		ofs = this.getOffset();

		return WPC_Segment.createFilename(prefix, extension, bank);
	}

	@Override
	public String toDASMxHeader()
	{
		StringBuffer result;
		String prefix;
		String filename_manual;
		File file_manual;
		int bank;

		result = new StringBuffer();

		bank = this.getId();
		prefix = WPC_Segment.createFilenamePrefix(this.getRom().getFilePrefix(), bank);
		filename_manual = WPC_Segment.createFilename(prefix + "_manual", Segment.EXTENSION_DASMX);
		file_manual = new File(filename_manual);

		if (bank != WPC_Rom.VIRTUALBANK)
		{
			String filename_top;

			filename_top = WPC_Segment.createFilename(this.getRom().getFilePrefix() + "_top", Segment.EXTENSION_DASMX);

			result.append("org\t0x" + Numbers.toHexString((short)this.getAddr()));	//fix format
			if (bank==WPC_Rom.SYSTEMBANK)
			{
				result.append("\t;last 32KB (system) of Game ROM");
			}
			else
			{
				result.append("\t;16KB bank of Game ROM");
			}
			result.append(Rom.NEWLINE);

			result.append(Rom.NEWLINE);

			result.append("include ");
			result.append(filename_top);
			result.append(Rom.NEWLINE);

			result.append(Rom.NEWLINE);
		}

		if (!file_manual.exists())
		{
			result.append(";");
		}
		result.append("include ");
		result.append(filename_manual);
		result.append("\t;place your own symbols in there to avoid overwritting when re-creating symbol files");
		result.append(Rom.NEWLINE);

		return result.toString();
	}

	public String createGroupFile() throws Exception
	{
		String filename;
		File file;
		PrintWriter textfile;
		int bank;
		int banksize;
		int bankofs;
		int bankaddr;
		byte romdata[];
		StringBuffer datastr, comstr, gfxstr;
		String addrstr;
		char comchar;

		bank = this.getId();
		filename = this.getRom().getFilePrefix() + "_dasm_bank" + Numbers.toHexString((byte)bank) + ".txt";
		file = new File(filename);
		if (file.exists())
		{
			return null;
		}

		// Open
		textfile = new PrintWriter(filename);
		// Headers
		textfile.println(this.getRom().toGroupHeader());
		textfile.println(this.toGroupHeader());
		// Data
		banksize = this.getSize();
		bankofs = this.getOffset();
		bankaddr = this.getAddr();
		romdata = this.getRom().data;
		for (int i=0; i<banksize; )
		{
			if (i==0)
			{
				datastr = new StringBuffer();
				addrstr = String.format("%04X", (short)bankaddr);
				datastr.append(String.format("%02X ", romdata[bankofs]));
				textfile.println(String.format("%s: %-48s ; Bank %s%02X Marker", addrstr, datastr, this.getRom().getHexPrefix(), romdata[bankofs]));
				textfile.println(String.format("%55s;", ""));
				textfile.println(";-------------------------------------------------------------------------------");
				i++; bankaddr++; bankofs++;
			}

			datastr = new StringBuffer();
			comstr = new StringBuffer(" ");
			gfxstr = new StringBuffer(" ");
			addrstr = String.format("%04X", (short)bankaddr);
			for (int j=0; j<16; j++)
			{
				datastr.append(String.format("%02X ", romdata[bankofs]));

				comchar = (char)(romdata[bankofs] & 0xff);
				if ((int)comchar<32)
				{
					comchar = '.';
				}
				comstr.append(comchar);

				gfxstr.append(Numbers.toGfxString(romdata[bankofs]));

				i++; bankaddr++; bankofs++;

				if ((bankaddr&15) == 0)
				{
					break;
				}
			}
			textfile.println(String.format("%s: %-48s ;%-17s%s", addrstr, datastr, comstr, gfxstr));
		}
		// Close
		textfile.close();

		return filename;
	}

	public String toGroupHeader()
	{
		StringBuffer result;

		result = new StringBuffer();

		result.append("File offset: " + this.getRom().getHexPrefix() + Numbers.toHexString(this.getOffset()));
		result.append(Rom.NEWLINE);
		result.append("Length: " + this.getRom().getHexPrefix() + Numbers.toHexString((short)this.getSize()));
		result.append(Rom.NEWLINE);
		result.append(Rom.NEWLINE);
		result.append(Rom.NEWLINE);
		result.append("Disassembly format:");
		result.append(Rom.NEWLINE);
		result.append("===================");
		result.append(Rom.NEWLINE);
		result.append(";-------------------------------------------------------------------------------");
		result.append(Rom.NEWLINE);
		result.append("; ......");
		result.append(Rom.NEWLINE);
		result.append("; ......");
		result.append(Rom.NEWLINE);
		result.append(";");
		result.append(Rom.NEWLINE);
		result.append("aaaa: oo oo oo oo oo  iiiii pp,pp,pp,pp,pp,pp          ; ................");
		result.append(Rom.NEWLINE);
		result.append("aaaa: x0 x1 x2 x3 x4 x5 x6 x7 x8 x9 xA xB xC xD xE xF  ; ................");
		result.append(Rom.NEWLINE);
		result.append("                                                       ;");
		result.append(Rom.NEWLINE);
		result.append(Rom.NEWLINE);
		result.append("Disassembly:");
		result.append(Rom.NEWLINE);
		result.append("============");

		return result.toString();
	}
}
