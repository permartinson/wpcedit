package maddes.pinball.wpc;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 22 $
$Date: 2007-09-17 12:15:32 +0200 (Mo, 17 Sep 2007) $
$Author: Dummy $

v1.4a
- added handling for different game versioning scheme starting with APPLE 3.38 (3.37?) around January 1995

v1.4
- adapted new symbol file organisation
- added DASMx top file generation
- added WPC DASM Group files generation
- added getter wrapper for filename prefix and extension to always return lowercase

v1.3
- added inner class WPC_Function for better handling/analysing function calls
- renamed "jsrBankFunc" -> "jsrPagedFunc" and similar functions accordingly
- fixed reference bug for jmpPagedFunc
- use of an address info object for getSwitchHandlerTableEntry() too (no more offsets)
- use of createSymbolPrefix() on newly created address info objects
- added *all* IJ L-7 system ROM functions with paramter bytes after their call
- added code to fill holes in function table in the beginning of the system ROM
- added analysing of the setPage routine
- added analysing of the APPLE version

v1.2
- store the address info object of all found functions instead of their offset
	this gives more flexibility, e.g. adding cross reference information
- added cross reference code to analysis method
- added methods to get a hex prefix and segment separator defined by the rom
	(keeps it similar to the normal rom class)
- using the hex prefix defined by the rom
- better comment for 1-byte functions and naming of related register byte

v1.1
- moved general analysing code from WPC_ROM into WPC_AddrInfo
- added analysing of the getSwitchHandlerTableEntry routine, including all the
	FPS of the two associated switch handler tables
- added analysing of some other routines, which use a 1-byte parameter behind
	the JSR call
- added check routine if bank fits to mem address

v1.0
initial version
*/

/* ToDo:
- More analysis of WPC ROM:
	- Avoid false positive of "JSR jxxPagedFunc*" (e.g. in graphics)
	- SWH,, SHWT
- Exceptions:
	- Err... normally there are no errors to handle, except the user ;)
*/

import maddes.dasm.BytePattern;
import maddes.dasm.AddrInfo;
import maddes.dasm.Rom;
import maddes.dasm.Segment;
import maddes.util.Bytes;
import maddes.util.Numbers;
import maddes.util.Shorts;
import java.io.File;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.TreeSet;

/*
A class for handling Williams WPC ROMs
*/
final class WPC_Rom extends maddes.dasm.Rom
{
	private class WPC_Function
	{
		private final WPC_AddrInfo function;
		private final int parmcount;	// parameter bytes after a JSR to a function
		private final String registers;	// registers in these parameter bytes
		private	final int offset;	// offset to start searching for JSR
		private final ArrayList<BytePattern> bytepatterns;
		private	final int address;

		public WPC_Function(WPC_AddrInfo function, int parmcount, String registers, int offset)
		{
			this.function = function;
			this.parmcount = parmcount;
			this.registers = registers;
			this.offset = offset;
			this.bytepatterns = new ArrayList<BytePattern>();
			this.address = function.getSegment().convRelOfsToAddr(function.getRelOffset());
		}

		public WPC_AddrInfo getFunction()
		{
			return this.function;
		}

		public int getParmCount()
		{
			return this.parmcount;
		}

		public String getRegisters()
		{
			return this.registers;
		}

		public int getOffset()
		{
			return this.offset;
		}

		public ArrayList<BytePattern> getBytePatterns()
		{
			return this.bytepatterns;
		}

		public int getAddress()
		{
			return this.address;
		}
	}

	// ***
	// *** static class variables
	// ***
	public static final String HEXPREFIX;
	public static final String SEGSEPARATOR;

	public static final int SIZE_1MBIT;

	public static final int BANKSIZE;
	public static final int BANKADDR;
	public static final int MAXBANKS;

	public static final int SYSTEMSIZE;
	public static final int SYSTEMADDR;
	public static final int SYSTEMBANK;

	public static final int VIRTUALBANK;
	public static final int VIRTUALBANKS;

	public static final short DEVELOPMENT_CHECKSUM;

	public static final int SIZE_JSR;
	public static final byte CODE_JSR;

	// setPage code
	private static final byte DATA_SETPAGE[] =
	{
		(byte)0x5D, (byte)0x2B, (byte)0x05, (byte)0xD7, (byte)0x11, (byte)0xF7, (byte)0x3F, (byte)0xFC,
		(byte)0x39
	};

	// jsrPagedFuncIndirect code
	private static final byte DATA_JSRPF_INDIRECT[] =
	{
		(byte)0x32, (byte)0x7F, (byte)0x34, (byte)0x57, (byte)0xEE, (byte)0x68, (byte)0x37, (byte)0x10,
		(byte)0xEF, (byte)0x68, (byte)0xEC, (byte)0x84, (byte)0xDD, (byte)0x12, (byte)0xA6, (byte)0x02,
		(byte)0x2B, (byte)0x20, (byte)0x91, (byte)0x11, (byte)0x27, (byte)0x1C, (byte)0xD6, (byte)0x11,
		(byte)0xE7, (byte)0x67, (byte)0x97, (byte)0x11, (byte)0xB7, (byte)0x3F, (byte)0xFC, (byte)0x35,
		(byte)0x57, (byte)0xAD, (byte)0x9F, (byte)0x00, (byte)0x12, (byte)0x34, (byte)0x03, (byte)0xA6,
		(byte)0x62, (byte)0xE7, (byte)0x62, (byte)0x97, (byte)0x11, (byte)0xB7, (byte)0x3F, (byte)0xFC,
		(byte)0x35, (byte)0x87, (byte)0x35, (byte)0x57, (byte)0x32, (byte)0x61, (byte)0x6E, (byte)0x9F,
		(byte)0x00, (byte)0x12
	};

	// jsrPagedFunc code
	private static final byte DATA_JSRPF[] =
	{
		(byte)0x32, (byte)0x7F, (byte)0x34, (byte)0x47, (byte)0xEE, (byte)0x66, (byte)0x37, (byte)0x06,
		(byte)0xDD, (byte)0x12, (byte)0xA6, (byte)0xC0, (byte)0x2B, (byte)0x22, (byte)0x91, (byte)0x11,
		(byte)0x27, (byte)0x1E, (byte)0xEF, (byte)0x66, (byte)0xD6, (byte)0x11, (byte)0xE7, (byte)0x65,
		(byte)0x97, (byte)0x11, (byte)0xB7, (byte)0x3F, (byte)0xFC, (byte)0x35, (byte)0x47, (byte)0xAD,
		(byte)0x9F, (byte)0x00, (byte)0x12, (byte)0x34, (byte)0x03, (byte)0xA6, (byte)0x62, (byte)0xE7,
		(byte)0x62, (byte)0x97, (byte)0x11, (byte)0xB7, (byte)0x3F, (byte)0xFC, (byte)0x35, (byte)0x87,
		(byte)0xEF, (byte)0x66, (byte)0x35, (byte)0x47, (byte)0x32, (byte)0x61, (byte)0x6E, (byte)0x9F,
		(byte)0x00, (byte)0x12
	};

	// jmpPagedFunc code
	private static final byte DATA_JMPPF[] =
	{
		(byte)0x34, (byte)0x17, (byte)0xAE, (byte)0x65, (byte)0xEC, (byte)0x84, (byte)0xDD, (byte)0x12,
		(byte)0xA6, (byte)0x02, (byte)0x2B, (byte)0x05, (byte)0x97, (byte)0x11, (byte)0xB7, (byte)0x3F,
		(byte)0xFC, (byte)0x35, (byte)0x17, (byte)0x32, (byte)0x62, (byte)0x6E, (byte)0x9F, (byte)0x00,
		(byte)0x12
	};

	// getSwitchHandlerTableEntry code
	private static final byte DATA_GETSWHNDTE_1[] =
	{
		(byte)0x34, (byte)0x06, (byte)0x81, (byte)0x81, (byte)0x25, (byte)0x08, (byte)0x80, (byte)0x80,
		(byte)0x10, (byte)0xBE
	};

	private static final byte DATA_GETSWHNDTE_2[] =
	{
		(byte)0x20, (byte)0x04, (byte)0x10, (byte)0xBE
	};

	private static final byte DATA_GETSWHNDTE_3[] =
	{
		(byte)0xA1, (byte)0x21, (byte)0x25, (byte)0x01, (byte)0x4F, (byte)0xE6, (byte)0x22, (byte)0x3D,
		(byte)0x31, (byte)0x23, (byte)0x31, (byte)0xAB, (byte)0x83, (byte)0x00,	(byte)0x01, (byte)0x35,
		(byte)0x86
	};

	// === 1-byte ==============================================================
	// functions with A as 1-byte parameter behind the calling JSR, pushing X,A
	private static final byte DATA_1BYTE_A_XA_1[] =
	{
		(byte)0x34, (byte)0x12, (byte)0xAE, (byte)0x63, (byte)0xA6, (byte)0x80, (byte)0xAF, (byte)0x63
	};

	// functions with A as 1-byte parameter behind the calling JSR, pushing X,B,A
	private static final byte DATA_1BYTE_A_XBA_1[] =
	{
		(byte)0x34, (byte)0x16, (byte)0xAE, (byte)0x64, (byte)0xA6, (byte)0x80, (byte)0xAF, (byte)0x64
	};

	private static final BytePattern DATA_1BYTE_A_XBA_2 = new BytePattern(
		new byte[] {
			(byte)0xC6
		}, 1
	);

	// functions with A as 1-byte parameter behind the calling JSR, pushing X
	private static final byte DATA_1BYTE_A_X_1[] =
	{
		(byte)0x34, (byte)0x10, (byte)0xAE, (byte)0x62, (byte)0xA6, (byte)0x80, (byte)0xAF, (byte)0x62
	};

	// functions with A as 1-byte parameter behind the calling JSR, pushing U,A
	private static final byte DATA_1BYTE_A_UA_1[] =
	{
		(byte)0x34, (byte)0x42, (byte)0xEE, (byte)0x63, (byte)0xA6, (byte)0xC0, (byte)0xEF, (byte)0x63
	};

	// functions with A as 1-byte parameter behind the calling JSR, pushing A,X
	private static final byte DATA_1BYTE_A_AX_1[] =
	{
		(byte)0x34, (byte)0x02, (byte)0x34, (byte)0x10, (byte)0xAE, (byte)0x63, (byte)0xA6, (byte)0x80,
		(byte)0xAF, (byte)0x63
	};

	private static final BytePattern DATA_1BYTE_A_AX_2 = new BytePattern(
		new byte[] {
			(byte)0x35, (byte)0x10
		}, 0
	);

	// functions with A as 1-byte parameter behind the calling JSR, pushing Y,A
	private static final byte DATA_1BYTE_A_YA_1[] =
	{
		(byte)0x34, (byte)0x22, (byte)0x10, (byte)0xAE, (byte)0x63, (byte)0xA6, (byte)0xA0, (byte)0x10,
		(byte)0xAF, (byte)0x63
	};

	// functions with A as 1-byte parameter behind the calling JSR, pushing X,B
	private static final byte DATA_1BYTE_A_XB_1[] =
	{
		(byte)0x34, (byte)0x14, (byte)0xAE, (byte)0x63, (byte)0xA6, (byte)0x80, (byte)0xAF, (byte)0x63
	};

	// functions with B as 1-byte parameter behind the calling JSR, pushing X,B
	private static final byte DATA_1BYTE_B_XB_1[] =
	{
		(byte)0x34, (byte)0x14, (byte)0xAE, (byte)0x63, (byte)0xE6, (byte)0x80, (byte)0xAF, (byte)0x63
	};

	private static final BytePattern DATA_1BYTE_B_XB_2 = new BytePattern(
		new byte[] {
			(byte)0x8E
		}, 2
	);

	// functions with B as 1-byte parameter behind the calling JSR, pushing X,B,A,CC
	private static final byte DATA_1BYTE_B_XBACC_1[] =
	{
		(byte)0x34, (byte)0x17, (byte)0xAE, (byte)0x65, (byte)0x4F, (byte)0xE6, (byte)0x80, (byte)0xAF,
		(byte)0x65
	};

	private static final BytePattern DATA_1BYTE_B_XBACC_2 = new BytePattern(
		new byte[] {
			(byte)0xB6
		}, 2
	);

	private static final BytePattern DATA_1BYTE_B_XBACC_3 = new BytePattern(
		new byte[] {
			(byte)0x27
		}, 1
	);

	private static final BytePattern DATA_1BYTE_B_XBACC_4 = new BytePattern(
		new byte[] {
			(byte)0x86
		}, 1
	);

	// functions with B as 1-byte parameter behind the calling JSR, pushing Y,X,B,A
	private static final byte DATA_1BYTE_B_YXBA_1[] =
	{
		(byte)0xDF, (byte)0x5F, (byte)0xDE, (byte)0x59, (byte)0x33, (byte)0x4F, (byte)0x36, (byte)0x36,
		(byte)0x9E, (byte)0x5F, (byte)0xAF, (byte)0x5E, (byte)0xDE, (byte)0x59, (byte)0xAE, (byte)0xE4,
		(byte)0xE6, (byte)0x80, (byte)0x4F, (byte)0xAF, (byte)0xE4
	};

	// functions with B as 1-byte parameter behind the calling JSR, pushing X,B,A,CC
	private static final byte DATA_1BYTE_B2_XBACC_1[] =
	{
		(byte)0x34, (byte)0x17, (byte)0xAE, (byte)0x65, (byte)0x86, (byte)0x80, (byte)0xE6, (byte)0x80,
		(byte)0xAF, (byte)0x65
	};

	// functions with B as 1-byte parameter behind the calling JSR, pushing Y,B,A
	private static final byte DATA_1BYTE_B_YBA_1[] =
	{
		(byte)0x34, (byte)0x26, (byte)0x10, (byte)0xAE, (byte)0x64, (byte)0xE6, (byte)0xA0, (byte)0x10,
		(byte)0xAF, (byte)0x64
	};

	// functions with B as 1-byte parameter behind the calling JSR, pushing B,X
	private static final byte DATA_1BYTE_B_BX_1[] =
	{
		(byte)0x34, (byte)0x04, (byte)0x34, (byte)0x10, (byte)0xAE, (byte)0x63, (byte)0xE6, (byte)0x80,
		(byte)0xAF, (byte)0x63
	};

	// === 2-byte ==============================================================
	// functions with X as 2-byte parameter behind the calling JSR, pushing U,X
	private static final byte DATA_2BYTE_X_UX_1[] =
	{
		(byte)0x34, (byte)0x50, (byte)0xEE, (byte)0x64, (byte)0xAE, (byte)0xC1, (byte)0xEF, (byte)0x64
	};

	// functions with D as 2-byte parameter behind the calling JSR, pushing X,B,A
	private static final byte DATA_2BYTE_D_XBA_1[] =
	{
		(byte)0x34, (byte)0x16, (byte)0xAE, (byte)0x64, (byte)0xEC, (byte)0x81, (byte)0xAF, (byte)0x64
	};

	// functions with Y as 2-byte parameter behind the calling JSR, pushing Y,X
	private static final byte DATA_2BYTE_Y_YX_1[] =
	{
		(byte)0x34, (byte)0x30, (byte)0xAE, (byte)0x64, (byte)0x10, (byte)0xAE, (byte)0x81, (byte)0xAF,
		(byte)0x64
	};

	// functions with U as 2-byte parameter behind the calling JSR, pushing U,X
	private static final byte DATA_2BYTE_U_UX_1[] =
	{
		(byte)0x34, (byte)0x50, (byte)0xAE, (byte)0x64, (byte)0xEE, (byte)0x81, (byte)0xAF,	(byte)0x64
	};

	// functions with D as 2-byte parameter behind the calling JSR, pushing Y,X,B,A
	private static final byte DATA_2BYTE_D_YXBA_1[] =
	{
		(byte)0xDF, (byte)0x5F, (byte)0xDE, (byte)0x59, (byte)0x33, (byte)0x4F, (byte)0x36, (byte)0x36,
		(byte)0x9E, (byte)0x5F, (byte)0xAF, (byte)0x5E, (byte)0xDE, (byte)0x59, (byte)0xAE, (byte)0xE4,
		(byte)0xEC, (byte)0x81, (byte)0xAF, (byte)0xE4
	};

	// functions with D as 2-byte parameter behind the calling JSR, pushing Y,X,B,A
	private static final byte DATA_2BYTE_D2_YXBA_1[] =
	{
		(byte)0x34, (byte)0x36, (byte)0x32, (byte)0x7F, (byte)0xAE, (byte)0x67, (byte)0xEC, (byte)0x81,
		(byte)0xAF, (byte)0x67
	};

	// functions with X as 2-byte parameter behind the calling JSR, pushing U,X,B,A
	private static final byte DATA_2BYTE_X_UXBA_1[] =
	{
		(byte)0x34, (byte)0x56, (byte)0xEE, (byte)0x66, (byte)0xAE, (byte)0xC4, (byte)0xEE, (byte)0x64
	};

	// functions with D as 2-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_2BYTE_D_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0xEE, (byte)0x68, (byte)0xEC, (byte)0xC1, (byte)0xEF, (byte)0x68
	};

	// === 3-byte ==============================================================
	// functions with YA as 3-byte parameter behind the calling JSR, pushing U,Y,A
	private static final byte DATA_3BYTE_YA_UYA_1[] =
	{
		(byte)0x34, (byte)0x62, (byte)0xEE, (byte)0x65, (byte)0x10, (byte)0xAE, (byte)0xC1, (byte)0xA6,
		(byte)0xC0, (byte)0xEF, (byte)0x65
	};

	// functions with XA as 3-byte parameter behind the calling JSR, pushing U,X,A
	private static final byte DATA_3BYTE_XA_UXA_1[] =
	{
		(byte)0x34, (byte)0x52, (byte)0xEE, (byte)0x65, (byte)0xAE, (byte)0xC1, (byte)0xA6, (byte)0xC0,
		(byte)0xEF, (byte)0x65
	};

	// functions with AX as 3-byte parameter behind the calling JSR, pushing U,X,A
	private static final byte DATA_3BYTE_AX_UXA_1[] =
	{
		(byte)0x34, (byte)0x52, (byte)0xEE, (byte)0x65, (byte)0xA6, (byte)0xC0, (byte)0xAE, (byte)0xC1,
		(byte)0xEF, (byte)0x65
	};

	// functions with AX as 3-byte parameter behind the calling JSR, pushing U,X,B,A
	private static final byte DATA_3BYTE_AX_UXBA_1[] =
	{
		(byte)0x34, (byte)0x56, (byte)0xEE, (byte)0x66, (byte)0xA6, (byte)0xC0,
		(byte)0xB7
	};

	private static final byte DATA_3BYTE_AX_UXBA_2[] =
	{
		(byte)0xAE, (byte)0xC1, (byte)0xEF, (byte)0x66
	};

	// functions with XB as 3-byte parameter behind the calling JSR, pushing U,X,B
	private static final byte DATA_3BYTE_XB_UXB_1[] =
	{
		(byte)0x34, (byte)0x54, (byte)0xEE, (byte)0x65, (byte)0xAE, (byte)0xC1, (byte)0xE6, (byte)0xC0,
		(byte)0xEF, (byte)0x65
	};

	// functions with XB as 3-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_3BYTE_XB_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0xEE, (byte)0x68, (byte)0xAE, (byte)0xC1, (byte)0xE6, (byte)0xC0,
		(byte)0xEF, (byte)0x68
	};

	// functions with XD as 3-byte parameter behind the calling JSR, pushing U,X,B,A
	private static final byte DATA_3BYTE_XD_UXBA_1[] =
	{
		(byte)0x34, (byte)0x56, (byte)0xEE, (byte)0x66, (byte)0x4F, (byte)0xE6, (byte)0x42, (byte)0x1F,
		(byte)0x01, (byte)0xEC, (byte)0xC4, (byte)0x33, (byte)0x43, (byte)0xEF, (byte)0x66
	};

	// functions with XB as 3-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_3BYTE_XB2_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0x32, (byte)0x7D, (byte)0xBD
	};

	private static final byte DATA_3BYTE_XB2_UYXBA_2[] =
	{
		(byte)0xE6, (byte)0x03, (byte)0xE7, (byte)0xE4, (byte)0x10, (byte)0xAE, (byte)0x88, (byte)0x2D,
		(byte)0x10, (byte)0xAF, (byte)0x61, (byte)0x10, (byte)0xAE, (byte)0x88, (byte)0x11,	(byte)0xEE,
		(byte)0x6B, (byte)0xAE, (byte)0xC4, (byte)0xE6, (byte)0x42, (byte)0x33, (byte)0x43, (byte)0xEF,
		(byte)0x6B
	};

	// functions with BY as 3-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_3BYTE_BY_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0xEE, (byte)0x68, (byte)0xE6, (byte)0xC4, (byte)0x10, (byte)0xAE,
		(byte)0x41, (byte)0x10, (byte)0xBF
	};

	private static final byte DATA_3BYTE_BY_UYXBA_2[] =
	{
		(byte)0xBE
	};

	private static final byte DATA_3BYTE_BY_UYXBA_3[] =
	{
		(byte)0x3A, (byte)0x58, (byte)0x3A, (byte)0xD6, (byte)0x11, (byte)0x34, (byte)0x04, (byte)0xF6
	};

	private static final byte DATA_3BYTE_BY_UYXBA_4[] =
	{
		(byte)0x35, (byte)0x04, (byte)0xBD
	};

	private static final byte DATA_3BYTE_BY_UYXBA_5[] =
	{
		(byte)0x33, (byte)0x43, (byte)0xEF, (byte)0x68
	};

	// === 4-byte ==============================================================
	// functions with YD as 4-byte parameter behind the calling JSR, pushing Y,X,B,A
	private static final byte DATA_4BYTE_YD_YXBA_1[] =
	{
		(byte)0x34, (byte)0x36, (byte)0xAE, (byte)0x66, (byte)0x10, (byte)0xAE, (byte)0x81, (byte)0xEC,
		(byte)0x81, (byte)0xAF, (byte)0x66
	};

	// functions with XD as 4-byte parameter behind the calling JSR, pushing U,X,B,A
	private static final byte DATA_4BYTE_XD_UXBA_1[] =
	{
		(byte)0x34, (byte)0x56, (byte)0xEE, (byte)0x66, (byte)0xAE, (byte)0xC1, (byte)0xEC, (byte)0xC1,
		(byte)0xEF, (byte)0x66
	};

	// functions with YD as 4-byte parameter behind the calling JSR, pushing U,Y,B,A
	private static final byte DATA_4BYTE_YD_UYBA_1[] =
	{
		(byte)0x34, (byte)0x66, (byte)0xEE, (byte)0x66, (byte)0x10, (byte)0xAE, (byte)0xC1, (byte)0xEC,
		(byte)0xC1, (byte)0xEF, (byte)0x66
	};

	// === 5-byte ==============================================================
	// functions with XYB as 5-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_5BYTE_XYB_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0xEE, (byte)0x68, (byte)0x10, (byte)0xAE, (byte)0xC4, (byte)0xAE,
		(byte)0x42, (byte)0xE6, (byte)0x44, (byte)0x33, (byte)0x45, (byte)0xEF, (byte)0x68
	};

	private static final BytePattern DATA_5BYTE_XYB_UYXBA_2 = new BytePattern(
		new byte[] {
			(byte)0x25, (byte)0x07, (byte)0x33, (byte)0xE4
		}, 0
	);

	// functions with XYA as 5-byte parameter behind the calling JSR, pushing U,Y,X,A
	private static final byte DATA_5BYTE_XYA_UYXA_1[] =
	{
		(byte)0x34, (byte)0x72, (byte)0xEE, (byte)0x67, (byte)0xAE, (byte)0xC1, (byte)0x10, (byte)0xAE,
		(byte)0xC1, (byte)0xA6, (byte)0xC0, (byte)0xEF, (byte)0x67
	};

	// functions with XBY as 5-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_5BYTE_XBY_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0xEE, (byte)0x68, (byte)0xAE, (byte)0xC1, (byte)0xE6, (byte)0xC0,
		(byte)0x10, (byte)0xAE, (byte)0xC1, (byte)0xEF, (byte)0x68
	};

	// functions with YXB as 5-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_5BYTE_YXB_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0xEE, (byte)0x68, (byte)0x10, (byte)0xAE, (byte)0xC4, (byte)0xCC,
		(byte)0x01, (byte)0xFF, (byte)0xBD
	};

	private static final byte DATA_5BYTE_YXB_UYXBA_2A[] =
	{
		(byte)0x24, (byte)0x1D
	};

	private static final byte DATA_5BYTE_YXB_UYXBA_2B[] =
	{
		(byte)0x10, (byte)0xAE, (byte)0xC4, (byte)0xAE, (byte)0x42, (byte)0xE6, (byte)0x44, (byte)0x33,
		(byte)0x45, (byte)0xEF, (byte)0x68
	};

	// === 6-byte ==============================================================
	// functions with any 6-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_6BYTE_ANY_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0xAE, (byte)0x68, (byte)0x31, (byte)0x06, (byte)0x10, (byte)0xAF,
		(byte)0x68
	};
	// functions with DYU as 6-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_6BYTE_DYU_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0xAE, (byte)0x68, (byte)0xEC, (byte)0x81, (byte)0x10, (byte)0xAE,
		(byte)0x81, (byte)0xEE, (byte)0x81, (byte)0xAF, (byte)0x68
	};
	// functions with any 6-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_6BYTE_ANY_UYXBA2_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0x10, (byte)0xAE, (byte)0x68, (byte)0x30, (byte)0x26, (byte)0xAF,
		(byte)0x68
	};

	// === 8-byte ==============================================================
	// functions with 8-byte parameter behind the calling JSR, pushing U,Y,X,B,A
	private static final byte DATA_8BYTE_ANY_UYXBA_1[] =
	{
		(byte)0x34, (byte)0x76, (byte)0xAE, (byte)0x68, (byte)0x31, (byte)0x08, (byte)0x10, (byte)0xAF,
		(byte)0x68
	};

	// ***
	// *** static class "constructor"
	// ***
	static
	{
		HEXPREFIX = "$";
		SEGSEPARATOR = "/";

		SIZE_1MBIT = 0x20000;	// 1MBit = 128KB

		BANKSIZE = 0x4000;	// 16KB
		BANKADDR = 0x4000;
		MAXBANKS = 0x40;	// 0x00 to 0x3F

		SYSTEMSIZE = 0x8000;	// 32KB
		SYSTEMADDR = 0x8000;
		SYSTEMBANK = 0x3E;

		VIRTUALBANK = 0xFF;
		VIRTUALBANKS = 0x80;

		DEVELOPMENT_CHECKSUM = 0x00FF;

		SIZE_JSR = 3;
		CODE_JSR = (byte)0xBD;
	}

	// ***
	// *** static class methods
	// ***

	// ***
	// *** object variables
	// ***
	private final int mbit;
	private final int bankbase;

	// checksum related
	private final int ofsCO_high;
	private final int ofsCO_low;
	private final int ofsCS_high;
	private final int ofsCS_low;

	private short calcCS, dataCS;
	private short calcCO, dataCO;
	private boolean checksum_ok;

	// code related
	private final WPC_AddrInfo infoSetPage;

	private final WPC_AddrInfo infoJsrPF_indirect;
	private final byte data_jsr_jsrpf_indirect[];

	private final WPC_AddrInfo infoJsrPF;
	private final byte data_jsr_jsrpf[];

	private final WPC_AddrInfo infoJmpPF;
	private final byte data_jsr_jmppf[];

	private final WPC_AddrInfo infoGetSwHndTE;

	private final int majorAppleVersion;
	private final int minorAppleVersion;
	private final String strAppleVersion;

	private final int majorGameVersion;
	private final int minorGameVersion;
	private final int typeGameVersion;
	private final String strGameVersion;

	private final ArrayList<WPC_Function> functions;

	// ***
	// *** object constructors
	// ***
	public WPC_Rom(String filename, WPC_Segment seglist[]) throws Exception
	{
		super(filename, seglist);

		long rest;
		int ofs, ofs2, ofs3;
		int majorVersion, minorVersion, typeVersion;
		ArrayList<Integer> results1, results2;
		int bank;
		WPC_AddrInfo wpc_addrinfo;
		WPC_Function wpc_function;
		StringBuffer strResult;

		this.functions = new ArrayList<WPC_Function>();
		this.mbit = this.data.length / WPC_Rom.SIZE_1MBIT;
		rest = this.data.length % WPC_Rom.SIZE_1MBIT;
		if ( ( rest != 0 )
			 || ( this.mbit != 1 && this.mbit != 2 && this.mbit != 4 && this.mbit != 8 ) )
		{
			System.out.println("File doesn't match WPC ROM file sizes of 1MBit (128KB), 2MBit (256KB), 4MBit (512KB) or 8MBit (1MB)");
			System.exit(0);
		}

		switch (this.mbit)
		{
			case 1:
				bank = 0x38;
				break;
			case 2:
				bank = 0x30;
				break;
			case 4:
				bank = 0x20;
				break;
			default:
				bank = 0;
				break;
		}
		this.bankbase = bank;

		// calculate checksum/correction offsets
		this.ofsCO_high = this.data.length - 20;
		this.ofsCO_low = this.ofsCO_high + 1;
		this.ofsCS_high = this.ofsCO_low + 1;
		this.ofsCS_low = this.ofsCS_high + 1;

		// get and check checksum/correction from ROM data
		this.checkChecksum();

		// system ROM
		ofs = this.data.length - WPC_Rom.SYSTEMSIZE;
		checkBankNumber(ofs, WPC_Rom.SYSTEMBANK);

		seglist[WPC_Rom.SYSTEMBANK] = new WPC_Segment(WPC_Rom.SYSTEMBANK, this, ofs, WPC_Rom.SYSTEMSIZE, WPC_Rom.SYSTEMADDR);

		// system ROM information are stored in a general symbol file of a virtual/fake bank 0xFF
		seglist[WPC_Rom.VIRTUALBANK] = new WPC_Segment(WPC_Rom.VIRTUALBANK, this, ofs, 0, WPC_Rom.SYSTEMADDR);

		// APPLE version
		ofs2 = Shorts.intUnsignedValue(Bytes.getShort(this.data, this.data.length-2))-2;	// get address
		ofs2 = seglist[WPC_Rom.SYSTEMBANK].convAddrToRelOfs(ofs2);	// convert to relative offset
		wpc_addrinfo = new WPC_AddrInfo(seglist[WPC_Rom.VIRTUALBANK], ofs2, "AppleVersion", 0, AddrInfo.Type.WORD, null);
		wpc_addrinfo.addSymbolPrefix();

		ofs2 = seglist[WPC_Rom.SYSTEMBANK].convRelOfsToOfs(ofs2);
		this.majorAppleVersion = Bytes.intUnsignedValue(this.data[ofs2]);
		this.minorAppleVersion = Bytes.intUnsignedValue(this.data[ofs2+1]);

		strResult = new StringBuffer();
		strResult.append(String.format("%d.%02d", this.majorAppleVersion, this.minorAppleVersion));
		this.strAppleVersion = strResult.toString();

		// Game version
		majorVersion = 0;
		minorVersion = 0;
		typeVersion = 1;	// default to old style
		if (this.majorAppleVersion>=3 && this.minorAppleVersion>=38)	// ToDo: not 100%, maybe started with 3.37
		{
			// --> New style (type 2)
			//     first known: TZ 9.2, 1995-01-30, APPLE 3.38: version at $FFBE plus partly in checksum (=$xx92)
			//     two decimals: AFM 1.13, , APPLE 3.77: version at $FFBE plus partly in checksum (=$xx11)
			ofs2 = this.data.length - 66;
			majorVersion = Bytes.intUnsignedValue(this.data[ofs2]);
			minorVersion = Bytes.intUnsignedValue(this.data[ofs2+1]);
			typeVersion = 2;
			// Special case: $0D00
			// e.g. Shadow L-5 & L-6 (L!!!)
			if (majorVersion == 0x0D && minorVersion == 0x00)	//unused
			{
				typeVersion = 1;	// fallback to old versioning scheme
			}
			else
			{
				// check low byte of checksum against version, normally $mn
				ofs2 = Bytes.intUnsignedValue(this.data[this.ofsCS_low]);
				ofs3 = (( majorVersion & 0x0F ) << 4) + ((minorVersion & 0xF0 ) >> 4);
				if ( ofs2 != ofs3 )
				{
					System.out.println("Low byte of checksum " + this.getHexPrefix() + Numbers.toHexString((byte)ofs2) + " doesn't match version " + this.getHexPrefix() + Numbers.toHexString((byte)ofs3));
				}
			}
		}
		if (typeVersion == 1)
		{
			// --> Old style (type 1)
			//     last known: Shadow LA-4, 1995-02-01, APPLE 3.36: version only in checksum (=$xx04)
			majorVersion = Bytes.intUnsignedValue(this.data[this.ofsCS_low]);
			minorVersion = 0;
			typeVersion = 1;
		}
		this.majorGameVersion = majorVersion;
		this.minorGameVersion = minorVersion;
		this.typeGameVersion = typeVersion;

		strResult = new StringBuffer();
		if (this.typeGameVersion == 2)
		{
			// New style (type 2)
			strResult.append(String.format("%X.%02X", majorVersion, minorVersion));
		}
		else
		{
			// Old style (type 1)
			majorVersion = this.majorGameVersion;
			// Special case: $Dx for prototypes (e.g. Corvette P-4)
			if (majorVersion >= 0xD0)
			{
				strResult.append('P');	// Prototype
				majorVersion -= 0xD0;
			}
			else
			{
				strResult.append('L');	// ToDo: Level?
			}
			strResult.append('-');
			strResult.append(String.format("%X", majorVersion));
		}
		this.strGameVersion = strResult.toString();

		// Search most common routines in system ROM
		// *** setPage
		ofs2 = 0;
		results1 = Bytes.searchBytes(this.data, ofs, WPC_Rom.SYSTEMSIZE, DATA_SETPAGE);
		if (results1.size()>0)
		{
			ofs2 = results1.get(0).intValue();
		}
		if (ofs2==0)
		{
			this.infoSetPage = null;
		}
		else
		{
			ofs2 = seglist[WPC_Rom.SYSTEMBANK].convOfsToRelOfs(ofs2);
			this.infoSetPage = new WPC_AddrInfo(seglist[WPC_Rom.VIRTUALBANK], ofs2, "setPage", 0, AddrInfo.Type.CODE, null, 0, WPC_AddrInfo.Type.FUNCTION, 0);
			this.infoSetPage.addSymbolPrefix();
			wpc_function = new WPC_Function(this.infoSetPage, 0, null, 0);
			this.functions.add(wpc_function);
		}
		// *** jsrPagedFuncIndirect
		ofs2 = 0;
		results1 = Bytes.searchBytes(this.data, ofs, WPC_Rom.SYSTEMSIZE, DATA_JSRPF_INDIRECT);
		if (results1.size()>0)
		{
			ofs2 = results1.get(0).intValue();
		}
		if (ofs2==0)
		{
			this.infoJsrPF_indirect = null;
			this.data_jsr_jsrpf_indirect = null;
		}
		else
		{
			ofs2 = seglist[WPC_Rom.SYSTEMBANK].convOfsToRelOfs(ofs2);
			this.infoJsrPF_indirect = new WPC_AddrInfo(seglist[WPC_Rom.VIRTUALBANK], ofs2, "jsrPagedFuncIndirect", 0, AddrInfo.Type.CODE, null, 0, WPC_AddrInfo.Type.FUNCTION, 0);
			this.infoJsrPF_indirect.addSymbolPrefix();
			wpc_addrinfo = new WPC_AddrInfo(seglist[WPC_Rom.SYSTEMBANK], ofs2+50, "jsrPagedFuncIndirect_noswitch", 0, AddrInfo.Type.CODE, null);
			wpc_addrinfo.addSymbolPrefix();

			// create compare array of JSR jsrPagedFuncIndirect
			ofs2 = seglist[WPC_Rom.SYSTEMBANK].convRelOfsToAddr(ofs2);
			this.data_jsr_jsrpf_indirect = new byte[WPC_Rom.SIZE_JSR];
			this.data_jsr_jsrpf_indirect[0] = WPC_Rom.CODE_JSR;
			this.data_jsr_jsrpf_indirect[1] = (byte)((ofs2 >>> 8) & Bytes.BYTEMASK);
			this.data_jsr_jsrpf_indirect[2] = (byte)(ofs2 & Bytes.BYTEMASK);
		}
		// *** jsrPagedFunc
		ofs2 = 0;
		results1 = Bytes.searchBytes(this.data, ofs, WPC_Rom.SYSTEMSIZE, DATA_JSRPF);
		if (results1.size()>0)
		{
			ofs2 = results1.get(0).intValue();
		}
		if (ofs2==0)
		{
			this.infoJsrPF = null;
			this.data_jsr_jsrpf = null;
		}
		else
		{
			ofs2 = seglist[WPC_Rom.SYSTEMBANK].convOfsToRelOfs(ofs2);
			this.infoJsrPF = new WPC_AddrInfo(seglist[WPC_Rom.VIRTUALBANK], ofs2, "jsrPagedFunc", 0, AddrInfo.Type.CODE, null, 0, WPC_AddrInfo.Type.FUNCTION, 0);
			this.infoJsrPF.addSymbolPrefix();
			wpc_addrinfo = new WPC_AddrInfo(seglist[WPC_Rom.SYSTEMBANK], ofs2+48, "jsrPagedFunc_noswitch", 0, AddrInfo.Type.CODE, null);
			wpc_addrinfo.addSymbolPrefix();

			// create compare array of JSR jsrPagedFuncIndirect
			ofs2 = seglist[WPC_Rom.SYSTEMBANK].convRelOfsToAddr(ofs2);
			this.data_jsr_jsrpf = new byte[WPC_Rom.SIZE_JSR];
			this.data_jsr_jsrpf[0] = WPC_Rom.CODE_JSR;
			this.data_jsr_jsrpf[1] = (byte)((ofs2 >>> 8) & Bytes.BYTEMASK);
			this.data_jsr_jsrpf[2] = (byte)(ofs2 & Bytes.BYTEMASK);
		}
		// *** jmpPagedFunc
		ofs2 = 0;
		results1 = Bytes.searchBytes(this.data, ofs, WPC_Rom.SYSTEMSIZE, DATA_JMPPF);
		if (results1.size()>0)
		{
			ofs2 = results1.get(0).intValue();
		}
		if (ofs2==0)
		{
			this.infoJmpPF = null;
			this.data_jsr_jmppf = null;
		}
		else
		{
			ofs2 = seglist[WPC_Rom.SYSTEMBANK].convOfsToRelOfs(ofs2);
			this.infoJmpPF = new WPC_AddrInfo(seglist[WPC_Rom.VIRTUALBANK], ofs2, "jmpPagedFunc", 0, AddrInfo.Type.CODE, null, 0, WPC_AddrInfo.Type.FUNCTION, 0);
			this.infoJmpPF.addSymbolPrefix();
			wpc_addrinfo = new WPC_AddrInfo(seglist[WPC_Rom.SYSTEMBANK], ofs2+17, "jmpPagedFunc_noswitch", 0, AddrInfo.Type.CODE, null);
			wpc_addrinfo.addSymbolPrefix();

			// create compare array of JSR jmpPagedFunc
			ofs2 = seglist[WPC_Rom.SYSTEMBANK].convRelOfsToAddr(ofs2);
			this.data_jsr_jmppf = new byte[WPC_Rom.SIZE_JSR];
			this.data_jsr_jmppf[0] = WPC_Rom.CODE_JSR;
			this.data_jsr_jmppf[1] = (byte)((ofs2 >>> 8) & Bytes.BYTEMASK);
			this.data_jsr_jmppf[2] = (byte)(ofs2 & Bytes.BYTEMASK);
		}
		// *** getSwitchHandlerTableEntry
		ofs2 = 0;
		results1 = Bytes.searchBytes(this.data, ofs, WPC_Rom.SYSTEMSIZE, DATA_GETSWHNDTE_1);
		for (Integer result : results1)
		{
			ofs2 = result.intValue();

			ofs3 = ofs2+DATA_GETSWHNDTE_1.length+2;
			results2 = Bytes.searchBytes(this.data, ofs3, DATA_GETSWHNDTE_2.length, DATA_GETSWHNDTE_2);
			if (results2.size()>0)
			{
				ofs3 += 2+DATA_GETSWHNDTE_2.length;
				results2 = Bytes.searchBytes(this.data, ofs3, DATA_GETSWHNDTE_3.length, DATA_GETSWHNDTE_3);
			}
			if (results2.size()>0)
			{
				break;	// found, stop searching
			}

			ofs2 = 0;
		}
		if (ofs2==0)
		{
			this.infoGetSwHndTE = null;
		}
		else
		{
			ofs2 = seglist[WPC_Rom.SYSTEMBANK].convOfsToRelOfs(ofs2);

			this.infoGetSwHndTE = new WPC_AddrInfo(seglist[WPC_Rom.VIRTUALBANK], ofs2, "getSwitchHandlerTableEntry", 0, AddrInfo.Type.CODE, null, 0, WPC_AddrInfo.Type.FUNCTION, 0);
			this.infoGetSwHndTE.addSymbolPrefix();
			wpc_addrinfo = new WPC_AddrInfo(seglist[WPC_Rom.SYSTEMBANK], ofs2+14, "getSwitchHandlerTableEntry_playfield", 0, AddrInfo.Type.CODE, null);
			wpc_addrinfo.addSymbolPrefix();
			wpc_addrinfo = new WPC_AddrInfo(seglist[WPC_Rom.SYSTEMBANK], ofs2+18, "getSwitchHandlerTableEntry_boundcheck", 0, AddrInfo.Type.CODE, null);
			wpc_addrinfo.addSymbolPrefix();
			wpc_addrinfo = new WPC_AddrInfo(seglist[WPC_Rom.SYSTEMBANK], ofs2+23, "getSwitchHandlerTableEntry_load", 0, AddrInfo.Type.CODE, null);
			wpc_addrinfo.addSymbolPrefix();
		}

		// game banks
		bank = WPC_Rom.SYSTEMBANK;
		while (ofs>0)
		{
			ofs -= WPC_Rom.BANKSIZE;
			bank--;

			checkBankNumber(ofs, bank);

			// store bank information
			seglist[bank] = new WPC_Segment(bank, this, ofs, WPC_Rom.BANKSIZE, WPC_Rom.BANKADDR);
		}
	}

	public WPC_Rom(String filename) throws Exception
	{
		this(filename, new WPC_Segment[WPC_Rom.VIRTUALBANK+1]);
	}

	// ***
	// *** setter/getter
	// ***
	public byte getChecksumLowByte()
	{
		return this.data[this.ofsCS_low];
	}

	public String getAppleVersionString()
	{
		return this.strAppleVersion;
	}

	public String getGameVersionString()
	{
		return this.strGameVersion;
	}

	private void setChecksumOk(boolean checksum_ok)
	{
		this.checksum_ok = checksum_ok;
	}

	public boolean isChecksumOk()
	{
		return this.checksum_ok;
	}

	public int getMBit()
	{
		return this.mbit;
	}

	public int getBankBase()
	{
		return this.bankbase;
	}

	@Override
	public WPC_Segment[] getSegList()
	{
		return (WPC_Segment[])super.getSegList();
	}

	@Override
	public String getHexPrefix()
	{
		return WPC_Rom.HEXPREFIX;
	}

	@Override
	public String getSegmentSeparator()
	{
		return WPC_Rom.SEGSEPARATOR;
	}

	@Override
	public String getFilePrefix()
	{
		return super.getFilePrefixLower();
	}

	@Override
	public String getFileExtension()
	{
		return super.getFileExtensionLower();
	}

	// ***
	// *** object methods
	// ***
	@Override
	public String toString()
	{
		StringBuffer result;

		result = new StringBuffer();
		result.append("File " + this.getFilename() + " contains " + this.data.length + " bytes (" + this.getMBit() + " MBit)");
		result.append(Rom.NEWLINE);
		result.append("Checksum slot: " + this.getHexPrefix() + Numbers.toHexString(this.ofsCS_high) + " (=" + this.getHexPrefix() + Numbers.toHexString(this.dataCS) + "), correction slot: " + this.getHexPrefix() + Numbers.toHexString(this.ofsCO_high) + " (=" + this.getHexPrefix() + Numbers.toHexString(this.dataCO) + ")");
		result.append(Rom.NEWLINE);
		result.append("Game version: " + this.getGameVersionString());
		result.append(Rom.NEWLINE);
		result.append("APPLE version: " + this.getAppleVersionString());

		if (!this.isChecksumOk())
		{
			result.append(Rom.NEWLINE);
			result.append(" WARNING!!! Maybe not a WPC ROM!!!");
			result.append(Rom.NEWLINE);
			if ( this.data[this.ofsCO_low] != ((byte)0xFF - this.data[this.ofsCS_high]) )
			{
				result.append(" Low byte of correction slot doesn't match $FF minus checksum high byte!");
				result.append(Rom.NEWLINE);
			}
			if ( this.dataCO == WPC_Rom.DEVELOPMENT_CHECKSUM )
			{
				result.append(" But could also be just pre-initialized for checksum calculation");
				result.append(Rom.NEWLINE);
			}
			result.append(" Calculated checksum: " + this.getHexPrefix() + Numbers.toHexString(this.calcCS));
		}

		if (this.infoSetPage!=null)
		{
			result.append(Rom.NEWLINE);
			result.append("setPage at " + this.getHexPrefix() + Numbers.toHexString(this.infoSetPage.getFileOffset()));
		}

		if (this.infoJsrPF_indirect!=null)
		{
			result.append(Rom.NEWLINE);
			result.append("jsrPagedFuncIndirect at " + this.getHexPrefix() + Numbers.toHexString(this.infoJsrPF_indirect.getFileOffset()));
		}

		if (this.infoJsrPF!=null)
		{
			result.append(Rom.NEWLINE);
			result.append("jsrPagedFunc at " + this.getHexPrefix() + Numbers.toHexString(this.infoJsrPF.getFileOffset()));
		}

		if (this.infoJmpPF!=null)
		{
			result.append(Rom.NEWLINE);
			result.append("jmpPagedFunc at " + this.getHexPrefix() + Numbers.toHexString(this.infoJmpPF.getFileOffset()));
		}

		if (this.infoGetSwHndTE!=null)
		{
			result.append(Rom.NEWLINE);
			result.append("getSwitchHandlerTableEntry at " + this.getHexPrefix() + Numbers.toHexString(this.infoGetSwHndTE.getFileOffset()));
		}

		return result.toString();
	}

	private void checkBankNumber(int ofs, int testbank)
	{
		int bank;

		bank = Bytes.intUnsignedValue(this.data[ofs]);

		if (bank!=testbank)
		{
			System.out.println(this.getFilename() + ": bank " + this.getHexPrefix() + Numbers.toHexString(this.data[ofs]) + " at offset " + this.getHexPrefix() + Numbers.toHexString(ofs) + " doesn't match the expected bank " + this.getHexPrefix() + Numbers.toHexString((byte)testbank));
			System.exit(0);	// ToDo: Add parameter to disable exit, only necessary for Dr. Dude (WPC Test Game)
		}
	}

	public int checkBankAddr(int bank, int addr, StringBuffer comment)
	{
		int	newbank;

		newbank = bank;

		// fix wrong but working target bank
		if (addr<WPC_Rom.BANKADDR && newbank!=WPC_Rom.VIRTUALBANK)
		{
			newbank = WPC_Rom.VIRTUALBANK;
		}
		else if (addr>=WPC_Rom.SYSTEMADDR && newbank!=WPC_Rom.SYSTEMBANK && newbank!=WPC_Rom.VIRTUALBANK)
		{
			newbank = WPC_Rom.SYSTEMBANK;
		}
		else if (newbank>=0 && newbank<this.bankbase)
		{
			newbank |= this.bankbase;
		}
		else if (newbank>=WPC_Rom.MAXBANKS && newbank<WPC_Rom.VIRTUALBANKS)
		{
			newbank &= (WPC_Rom.MAXBANKS-1);
		}
		else if (newbank>=WPC_Rom.VIRTUALBANKS && newbank!=WPC_Rom.VIRTUALBANK)	// "negative" banks are interpreted as system ROM
		{
			newbank = WPC_Rom.VIRTUALBANK;
		}

		if (newbank!=bank && comment!=null && bank!=WPC_Rom.VIRTUALBANK)
		{
			comment.append(" (INACCURATE, correct would be bank " + this.getHexPrefix() + Numbers.toHexString((byte)newbank) + ")");
		}

		return newbank;
	}

	public void checkChecksum()
	{
		this.dataCS = Bytes.getShort(this.data, this.ofsCS_high);
		this.dataCO = Bytes.getShort(this.data, this.ofsCO_high);

		this.calcCS = Bytes.calcShortChecksum(this.data);

		this.setChecksumOk(true);

		if (this.calcCS!=this.dataCS)
		{
			this.setChecksumOk(false);
		}
		else if (this.data[this.ofsCO_low] != ((byte)0xFF - this.data[this.ofsCS_high]))
		{
			this.setChecksumOk(false);
		}
		else if ( this.dataCO == WPC_Rom.DEVELOPMENT_CHECKSUM )
		{
			this.setChecksumOk(false);
		}
	}

	public void calcChecksum(byte lowbyte, boolean verbose)
	{
		System.out.println("Re-calculating checksum for version low byte " + this.getHexPrefix() + Numbers.toHexString(lowbyte) + "...");

		if (lowbyte==this.getChecksumLowByte() && this.isChecksumOk())
		{
			System.out.println(" ...not necessary as version low byte and checksum in ROM are correct.");
			return;
		}

		// Initialize ROM for checksum calculation
		this.data[this.ofsCO_high] = (byte)0x00;
		this.data[this.ofsCO_low] = (byte)0xFF;
		this.data[this.ofsCS_high] = (byte)0x00;
		this.data[this.ofsCS_low] = (byte)0xFF;

		if (verbose)
		{
			System.out.println(" Initializing ROM...");
			System.out.println("  Correction slot: " + this.getHexPrefix() + Numbers.toHexString(this.data[this.ofsCO_high]) + Numbers.toHexString(this.data[this.ofsCO_low]));
			System.out.println("  Checksum slot: " + this.getHexPrefix() + Numbers.toHexString(this.data[this.ofsCS_high]) + Numbers.toHexString(this.data[this.ofsCS_low]));
		}

		// Get checksum for initialized ROM
		this.calcCS = Bytes.calcShortChecksum(this.data);
		System.out.println(" Calculated checksum: " + this.getHexPrefix() + Numbers.toHexString(this.calcCS));

		// Calculate 100% Williams style checksum and correction
		System.out.println(" Calculating 100% Williams style checksum...");

		// CO high byte (compensates CS low byte)
		// CO high byte = 0xFF - CS low byte
		this.data[this.ofsCO_high] = (byte)(0xFF - (this.calcCS & Bytes.BYTEMASK));
		System.out.println("  Correction high byte: $FF - " + this.getHexPrefix() + Numbers.toHexString((byte)(this.calcCS & Bytes.BYTEMASK)) + " = " + this.getHexPrefix() + Numbers.toHexString(this.data[this.ofsCO_high]));

		// CS low byte (can be set to anything as it was compensated to zero difference before)
		this.data[this.ofsCS_low] = lowbyte;

		// CS high byte
		this.calcCS = (short)((this.calcCS & Shorts.SHORTMASK) >>> 8);	//unsigned shift
		this.data[this.ofsCS_high] = (byte)(this.calcCS & Bytes.BYTEMASK);

		// CO low byte (compensates CS high byte)
		// CO low byte = 0xFF - CS high byte
		this.data[this.ofsCO_low] = (byte)(0xFF - (this.data[this.ofsCS_high] & Bytes.BYTEMASK));
		System.out.println("  Correction low byte: $FF - " + this.getHexPrefix() + Numbers.toHexString(this.data[this.ofsCS_high]) + " = " + this.getHexPrefix() +Numbers.toHexString(this.data[this.ofsCO_low]));

		System.out.println(" Final correction: " + this.getHexPrefix() + Numbers.toHexString(this.data[this.ofsCO_high]) + Numbers.toHexString(this.data[this.ofsCO_low]));
		System.out.print(" Final checksum: " + this.getHexPrefix() + Numbers.toHexString(this.data[this.ofsCS_high]) + Numbers.toHexString(this.data[this.ofsCS_low]) + " is ");

		// Validate checksum
		this.checkChecksum();
		if (this.calcCS!=this.dataCS)
		{
			System.out.println("INVALID!!!");
			System.out.println();
			System.out.println(" Calculated checksum: " + this.getHexPrefix() + Numbers.toHexString(this.calcCS));
			System.out.println(" This should never happen. Please contact me through my website, send me the ROM and state the parameters you used. Thanks Maddes.");
			System.exit(0);
		}
		else
		{
			System.out.println("OK!");
		}
	}

	@Override
	protected void analyseDeeper()
	{
		ArrayList<WPC_AddrInfo> wpc_addrinfos1, wpc_addrinfos2, wpc_addrinfos3;
		WPC_AddrInfo wpc_addrinfo, wpc_addrinfo2;
		WPC_Segment seglist[], bankseg, storeseg;
		WPC_Function wpc_function;
		int bankbase, bank, bankofs, banksize, bankaddr, storebank;
		boolean err;
		int maxbank;
		ArrayList<Integer> results1, results2;
		int ofs, ofs2, relofs, addr;
		int count, size;
		int i;
		byte data_jsr[];
		final boolean debug = false;

		seglist = this.getSegList();
		bankbase = this.getBankBase();
		err = false;
		data_jsr = new byte[WPC_Rom.SIZE_JSR];

		if (this.infoSetPage==null)
		{
			err = true;
			System.out.println(" ERROR: setPage *NOT* found!!!");
		}

		if (this.infoJsrPF_indirect==null)
		{
			err = true;
			System.out.println(" ERROR: jsrPagedFuncIndirect *NOT* found!!!");
		}

		if (this.infoJsrPF==null)
		{
			err = true;
			System.out.println(" ERROR: jsrPagedFunc *NOT* found!!!");
		}

		if (this.infoJmpPF==null)
		{
			err = true;
			System.out.println(" ERROR: jmpPagedFunc *NOT* found!!!");
		}

		if (this.infoGetSwHndTE==null)
		{
			err = true;
			System.out.println(" ERROR: getSwitchHandlerTableEntry *NOT* found!!!");
		}
		else
		{
			WPC_AddrInfo ft_switch;

			// Fliptronics switch table
			System.out.println(" A1 = Analysing Fliptronic switch table");
			addr = Shorts.intUnsignedValue(Bytes.getShort(this.data, this.infoGetSwHndTE.getFileOffset()+10));
			bank = WPC_Rom.VIRTUALBANK;
			storebank = this.checkBankAddr(bank, addr, null);
			if (bank!=WPC_Rom.VIRTUALBANK)
			{
				System.out.println(" ERROR: Fliptronic switch table not in SYSTEM ROM");
				err = true;
			}
			else if (addr>=WPC_Rom.SYSTEMADDR)
			{
				storeseg = seglist[storebank];
				wpc_addrinfo = new WPC_AddrInfo(storeseg, storeseg.convAddrToRelOfs(addr), "SWHT_" + "Fliptronic", 99999, AddrInfo.Type.STRUCTURE, null, 3, WPC_AddrInfo.Type.DPS, 0);
				wpc_addrinfo.addSymbolPrefix();
				wpc_addrinfos1 = wpc_addrinfo.analyseDeeper("A1", "Fliptronic", AddrInfo.Type.STRUCTURE, WPC_AddrInfo.Type.SWHT);
				for (WPC_AddrInfo result1 : wpc_addrinfos1)
				{
					wpc_addrinfos2 = result1.analyseDeeper("A1", result1.getBaseName().toString(), AddrInfo.Type.STRUCTURE, WPC_AddrInfo.Type.SWH);	// analyse SWHT
					for (WPC_AddrInfo result2 : wpc_addrinfos2)
					{
						wpc_addrinfos3 = result2.analyseDeeper("A1", result2.getBaseName().toString(), AddrInfo.Type.STRUCTURE, WPC_AddrInfo.Type.FPS);	// analyse SWH
						for (WPC_AddrInfo result3 : wpc_addrinfos3)
						{
							result3.analyseDeeper("A1", result2.getBaseName().toString(), AddrInfo.Type.CODE, WPC_AddrInfo.Type.FUNCTION);	// analyse FPS
						}
					}
				}
			}

			// Playfield switch table
			System.out.println(" A2 = Analysing Playfield switch table");
			addr = Shorts.intUnsignedValue(Bytes.getShort(this.data, this.infoGetSwHndTE.getFileOffset()+16));
			bank = WPC_Rom.VIRTUALBANK;
			storebank = this.checkBankAddr(bank, addr, null);
			if (bank!=WPC_Rom.VIRTUALBANK)
			{
				System.out.println(" ERROR: Playfield switch table not in SYSTEM ROM");
				err = true;
			}
			else if (addr>=WPC_Rom.SYSTEMADDR)
			{
				storeseg = seglist[storebank];
				wpc_addrinfo = new WPC_AddrInfo(storeseg, storeseg.convAddrToRelOfs(addr), "SWHT_" + "Playfield", 99999, AddrInfo.Type.STRUCTURE, null, 3, WPC_AddrInfo.Type.DPS, 0);
				wpc_addrinfo.addSymbolPrefix();
				wpc_addrinfos1 = wpc_addrinfo.analyseDeeper("A2", "Playfield", AddrInfo.Type.STRUCTURE, WPC_AddrInfo.Type.SWHT);
				for (WPC_AddrInfo result1 : wpc_addrinfos1)
				{
					wpc_addrinfos2 = result1.analyseDeeper("A2", result1.getBaseName().toString(), AddrInfo.Type.STRUCTURE, WPC_AddrInfo.Type.SWH);	// analyse SWHT
					for (WPC_AddrInfo result2 : wpc_addrinfos2)
					{
						wpc_addrinfos3 = result2.analyseDeeper("A2", result2.getBaseName().toString(), AddrInfo.Type.STRUCTURE, WPC_AddrInfo.Type.FPS);	// analyse SWH
						for (WPC_AddrInfo result3 : wpc_addrinfos3)
						{
							result3.analyseDeeper("A2", result2.getBaseName().toString(), AddrInfo.Type.CODE, WPC_AddrInfo.Type.FUNCTION);	// analyse FPS
						}
					}
				}
			}
		}

		System.out.println(" A3 = Searching functions with parameters after their call");
		// === 1-byte ==============================================================
		// Search functions with 1-byte parameter behing calling JSR
		bankseg = seglist[WPC_Rom.SYSTEMBANK];
		storeseg = seglist[WPC_Rom.VIRTUALBANK];
		// functions with A as 1-byte parameter behind the calling JSR, pushing X,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_A_XA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte A/XA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "A", DATA_1BYTE_A_XA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_A_XA_1");
		}
		// functions with A as 1-byte parameter behind the calling JSR, pushing X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_A_XBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte A/XBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "A", DATA_1BYTE_A_XBA_1.length);
			this.functions.add(wpc_function);
			wpc_function.getBytePatterns().add(DATA_1BYTE_A_XBA_2);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_A_XBA_1");
		}
		// functions with A as 1-byte parameter behind the calling JSR, pushing X
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_A_X_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte A/X", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "A", DATA_1BYTE_A_X_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_A_X_1");
		}
		// functions with A as 1-byte parameter behind the calling JSR, pushing U,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_A_UA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte A/UA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "A", DATA_1BYTE_A_UA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_A_UA_1");
		}
		// functions with A as 1-byte parameter behind the calling JSR, pushing A,X
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_A_AX_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte A/AX", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "A", DATA_1BYTE_A_AX_1.length);
			this.functions.add(wpc_function);
			wpc_function.getBytePatterns().add(DATA_1BYTE_A_AX_2);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_A_AX_1");
		}
		// functions with A as 1-byte parameter behind the calling JSR, pushing Y,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_A_YA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte A/YA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "A", DATA_1BYTE_A_YA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_A_YA_1");
		}
		// functions with A as 1-byte parameter behind the calling JSR, pushing X,B
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_A_XB_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte A/XB", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "A", DATA_1BYTE_A_XB_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_A_XB_1");
		}
		// functions with B as 1-byte parameter behind the calling JSR, pushing X,B
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_B_XB_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte B/XB", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "B", DATA_1BYTE_B_XB_1.length);
			this.functions.add(wpc_function);
			wpc_function.getBytePatterns().add(DATA_1BYTE_B_XB_2);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_B_XB_1");
		}
		// functions with B as 1-byte parameter behind the calling JSR, pushing X,B,A,CC
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_B_XBACC_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte B/XBACC", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "B", DATA_1BYTE_B_XBACC_1.length);
			this.functions.add(wpc_function);
			wpc_function.getBytePatterns().add(DATA_1BYTE_B_XBACC_2);
			wpc_function.getBytePatterns().add(DATA_1BYTE_B_XBACC_3);
			wpc_function.getBytePatterns().add(DATA_1BYTE_B_XBACC_4);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_B_XBACC_1");
		}
		// functions with B as 1-byte parameter behind the calling JSR, pushing Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_B_YXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte B/YXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "B", DATA_1BYTE_B_YXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_B_YXBA_1");
		}
		// functions with B as 1-byte parameter behind the calling JSR, pushing Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_B2_XBACC_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte B2/XBACC", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "B", DATA_1BYTE_B2_XBACC_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_B2_XBACC_1");
		}
		// functions with B as 1-byte parameter behind the calling JSR, pushing Y,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_B_YBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte B/YBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "B", DATA_1BYTE_B_YBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_B_YBA_1");
		}
		// functions with B as 1-byte parameter behind the calling JSR, pushing B,X
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_1BYTE_B_BX_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "1-byte B/BX", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 1, "B", DATA_1BYTE_B_BX_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_1BYTE_B_BX_1");
		}

		// === 2-byte ==============================================================
		// Search functions with 2-byte parameter behing calling JSR
		bankseg = seglist[WPC_Rom.SYSTEMBANK];
		storeseg = seglist[WPC_Rom.VIRTUALBANK];
		// functions with X as 2-byte parameter behind the calling JSR, pushing U,X
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_2BYTE_X_UX_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "2-byte X/UX", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 2, "X", DATA_2BYTE_X_UX_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_2BYTE_X_UX_1");
		}
		// functions with D as 2-byte parameter behind the calling JSR, pushing X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_2BYTE_D_XBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "2-byte D/XBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 2, "D", DATA_2BYTE_D_XBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_2BYTE_D_XBA_1");
		}
		// functions with Y as 2-byte parameter behind the calling JSR, pushing Y,X
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_2BYTE_Y_YX_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "2-byte Y/YX", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 2, "Y", DATA_2BYTE_Y_YX_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_2BYTE_Y_YX_1");
		}
		// functions with U as 2-byte parameter behind the calling JSR, pushing U,X
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_2BYTE_U_UX_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "2-byte U/UX", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 2, "U", DATA_2BYTE_U_UX_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_2BYTE_U_UX_1");
		}
		// functions with D as 2-byte parameter behind the calling JSR, pushing Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_2BYTE_D_YXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "2-byte D/YXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 2, "D", DATA_2BYTE_D_YXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_2BYTE_D_YXBA_1");
		}
		// functions with D as 2-byte parameter behind the calling JSR, pushing Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_2BYTE_D2_YXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "2-byte D2/YXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 2, "D", DATA_2BYTE_D2_YXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_2BYTE_D2_YXBA_1");
		}
		// functions with X as 2-byte parameter behind the calling JSR, pushing U,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_2BYTE_X_UXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "2-byte X/UXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 2, "X", DATA_2BYTE_X_UXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_2BYTE_X_UXBA_1");
		}
		// functions with D as 2-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_2BYTE_D_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "2-byte D/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 2, "D", DATA_2BYTE_D_UYXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_2BYTE_D_UYXBA_1");
		}

		// === 3-byte ==============================================================
		// Search functions with 3-byte parameter behing calling JSR
		bankseg = seglist[WPC_Rom.SYSTEMBANK];
		storeseg = seglist[WPC_Rom.VIRTUALBANK];
		// functions with YA as 3-byte parameter behind the calling JSR, pushing U,Y,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_3BYTE_YA_UYA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "3-byte YA/UYA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 3, "YA", DATA_3BYTE_YA_UYA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_3BYTE_YA_UYA_1");
		}
		// functions with XA as 3-byte parameter behind the calling JSR, pushing U,X,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_3BYTE_XA_UXA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "3-byte XA/UXA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 3, "XA", DATA_3BYTE_XA_UXA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_3BYTE_XA_UXA_1");
		}
		// functions with AX as 3-byte parameter behind the calling JSR, pushing U,X,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_3BYTE_AX_UXA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "3-byte AX/UXA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 3, "AX", DATA_3BYTE_AX_UXA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_3BYTE_AX_UXA_1");
		}
		// functions with AX as 3-byte parameter behind the calling JSR, pushing U,X,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_3BYTE_AX_UXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			ofs2 = ofs+DATA_3BYTE_AX_UXBA_1.length+2;
			results2 = Bytes.searchBytes(this.data, ofs2, DATA_3BYTE_AX_UXBA_2.length, DATA_3BYTE_AX_UXBA_2);
			if (results2.size() > 0)
			{
				// function found
				relofs = bankseg.convOfsToRelOfs(ofs);
				wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "3-byte AX/UXA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
				wpc_addrinfo.addSymbolPrefix();
				wpc_function = new WPC_Function(wpc_addrinfo, 3, "AX", ofs2-ofs+DATA_3BYTE_AX_UXBA_2.length);
				this.functions.add(wpc_function);
			}
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_3BYTE_AX_UXBA_1");
		}
		// functions with XB as 3-byte parameter behind the calling JSR, pushing U,X,B
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_3BYTE_XB_UXB_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "3-byte XB/UXB", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 3, "XB", DATA_3BYTE_XB_UXB_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_3BYTE_XB_UXB_1");
		}
		// functions with XB as 3-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_3BYTE_XB_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "3-byte XB/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 3, "XB", DATA_3BYTE_XB_UYXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_3BYTE_XB_UYXBA_1");
		}
		// functions with XD as 3-byte parameter behind the calling JSR, pushing U,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_3BYTE_XD_UXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "3-byte XlD/UXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 3, "XlD", DATA_3BYTE_XD_UXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_3BYTE_XD_UXBA_1");
		}
		// functions with XB as 3-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_3BYTE_XB2_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			ofs2 = ofs+DATA_3BYTE_XB2_UYXBA_1.length+2;
			results2 = Bytes.searchBytes(this.data, ofs2, DATA_3BYTE_XB2_UYXBA_2.length, DATA_3BYTE_XB2_UYXBA_2);
			if (results2.size() > 0)
			{
				// function found
				relofs = bankseg.convOfsToRelOfs(ofs);
				wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "3-byte XB/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
				wpc_addrinfo.addSymbolPrefix();
				wpc_function = new WPC_Function(wpc_addrinfo, 3, "XB", ofs2-ofs+DATA_3BYTE_XB2_UYXBA_2.length);
				this.functions.add(wpc_function);
			}
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_3BYTE_XB2_UYXBA_1");
		}
		// functions with BY as 3-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_3BYTE_BY_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			ofs2 = ofs+DATA_3BYTE_BY_UYXBA_1.length+2;
			results2 = Bytes.searchBytes(this.data, ofs2, DATA_3BYTE_BY_UYXBA_2.length, DATA_3BYTE_BY_UYXBA_2);
			if (results2.size() > 0)
			{
				ofs2 += DATA_3BYTE_BY_UYXBA_2.length+2;
				results2 = Bytes.searchBytes(this.data, ofs2, DATA_3BYTE_BY_UYXBA_3.length, DATA_3BYTE_BY_UYXBA_3);
			}
			if (results2.size() > 0)
			{
				ofs2 += DATA_3BYTE_BY_UYXBA_3.length+2;
				for (i=0; i<4; i++)
				{
					if (this.data[ofs2]!=WPC_Rom.CODE_JSR)
					{
						results2.clear();
					}
					ofs2 += 3;
				}
				if (results2.size() > 0)
				{
					results2 = Bytes.searchBytes(this.data, ofs2, DATA_3BYTE_BY_UYXBA_4.length, DATA_3BYTE_BY_UYXBA_4);
				}
			}
			if (results2.size() > 0)
			{
				ofs2 += DATA_3BYTE_BY_UYXBA_4.length+2;
				results2 = Bytes.searchBytes(this.data, ofs2, DATA_3BYTE_BY_UYXBA_5.length, DATA_3BYTE_BY_UYXBA_5);
			}

			if (results2.size() > 0)
			{
				// function found
				relofs = bankseg.convOfsToRelOfs(ofs);
				wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "3-byte BY/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
				wpc_addrinfo.addSymbolPrefix();
				wpc_function = new WPC_Function(wpc_addrinfo, 3, "BY", ofs2-ofs+DATA_3BYTE_BY_UYXBA_5.length);
				this.functions.add(wpc_function);
			}
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_3BYTE_BY_UYXBA_1");
		}

		// === 4-byte ==============================================================
		// Search functions with 4-byte parameter behing calling JSR
		bankseg = seglist[WPC_Rom.SYSTEMBANK];
		storeseg = seglist[WPC_Rom.VIRTUALBANK];
		// functions with YD as 4-byte parameter behind the calling JSR, pushing Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_4BYTE_YD_YXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "4-byte YD/YXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 4, "YD", DATA_4BYTE_YD_YXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_4BYTE_YD_YXBA_1");
		}
		// functions with XD as 4-byte parameter behind the calling JSR, pushing U,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_4BYTE_XD_UXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "4-byte XD/UXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 4, "XD", DATA_4BYTE_XD_UXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_4BYTE_XD_UXBA_1");
		}
		// functions with YD as 4-byte parameter behind the calling JSR, pushing U,Y,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_4BYTE_YD_UYBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "4-byte YD/UYBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 4, "YD", DATA_4BYTE_YD_UYBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_4BYTE_YD_UYBA_1");
		}

		// === 5-byte ==============================================================
		// Search functions with 5-byte parameter behing calling JSR
		bankseg = seglist[WPC_Rom.SYSTEMBANK];
		storeseg = seglist[WPC_Rom.VIRTUALBANK];
		// functions with XYB as 5-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_5BYTE_XYB_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "5-byte XYB/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 5, "XYB", DATA_5BYTE_XYB_UYXBA_1.length);
			this.functions.add(wpc_function);
			wpc_function.getBytePatterns().add(DATA_5BYTE_XYB_UYXBA_2);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_5BYTE_XYB_UYXBA_1");
		}
		// functions with XYA as 5-byte parameter behind the calling JSR, pushing U,Y,X,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_5BYTE_XYA_UYXA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "5-byte XYA/UYXA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 5, "XYA", DATA_5BYTE_XYA_UYXA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_5BYTE_XYA_UYXA_1");
		}
		// functions with XBY as 5-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_5BYTE_XBY_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "5-byte XBY/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 5, "XBY", DATA_5BYTE_XBY_UYXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_5BYTE_XBY_UYXBA_1");
		}
		// functions with YXB as 5-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_5BYTE_YXB_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			ofs2 = ofs+DATA_5BYTE_YXB_UYXBA_1.length+2;
			results2 = Bytes.searchBytes(this.data, ofs2, DATA_5BYTE_YXB_UYXBA_2A.length, DATA_5BYTE_YXB_UYXBA_2A);
			if (results2.size() > 0)
			{
				ofs2 += DATA_5BYTE_YXB_UYXBA_2A.length;
			}

			results2 = Bytes.searchBytes(this.data, ofs2, DATA_5BYTE_YXB_UYXBA_2B.length, DATA_5BYTE_YXB_UYXBA_2B);
			if (results2.size() > 0)
			{
				// function found
				relofs = bankseg.convOfsToRelOfs(ofs);
				wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "5-byte YXB/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
				wpc_addrinfo.addSymbolPrefix();
				wpc_function = new WPC_Function(wpc_addrinfo, 5, "YXB", ofs2-ofs+DATA_5BYTE_YXB_UYXBA_2B.length);
				this.functions.add(wpc_function);
			}
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_5BYTE_YXB_UYXBA_1");
		}

		// === 6-byte ==============================================================
		// Search functions with 6-byte parameter behing calling JSR
		bankseg = seglist[WPC_Rom.SYSTEMBANK];
		storeseg = seglist[WPC_Rom.VIRTUALBANK];
		// functions with any 6-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_6BYTE_ANY_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "6-byte any/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 6, null, DATA_6BYTE_ANY_UYXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_6BYTE_ANY_UYXBA_1");
		}
		// functions with DYU as 6-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_6BYTE_DYU_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "6-byte DYU/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 6, null, DATA_6BYTE_DYU_UYXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_6BYTE_DYU_UYXBA_1");
		}
		// functions with any 6-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_6BYTE_ANY_UYXBA2_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "6-byte any/UYXBA2", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 6, null, DATA_6BYTE_ANY_UYXBA2_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_6BYTE_ANY_UYXBA2_1");
		}

		// === 8-byte ==============================================================
		// Search functions with 8-byte parameter behing calling JSR
		bankseg = seglist[WPC_Rom.SYSTEMBANK];
		storeseg = seglist[WPC_Rom.VIRTUALBANK];
		// functions with any as 8-byte parameter behind the calling JSR, pushing U,Y,X,B,A
		results1 = Bytes.searchBytes(this.data, bankseg.getOffset(), WPC_Rom.SYSTEMSIZE, DATA_8BYTE_ANY_UYXBA_1);
		for (Integer result : results1)
		{
			ofs = result.intValue();

			// function found
			relofs = bankseg.convOfsToRelOfs(ofs);
			wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, "8-byte any/UYXBA", 0, WPC_AddrInfo.Type.FUNCTION, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_function = new WPC_Function(wpc_addrinfo, 8, null, DATA_8BYTE_ANY_UYXBA_1.length);
			this.functions.add(wpc_function);
		}
		if (debug && results1.size() <= 0)
		{
			System.out.println("    ...couldn't find DATA_8BYTE_ANY_UYXBA_1");
		}

		// ***
		// *** B4: Find function calls inside functions with parameter bytes behind their call
		// ***
		for (WPC_Function function : this.functions)
		{
			ArrayList<BytePattern> bytepatterns;
			wpc_addrinfo2 = function.getFunction();
			ofs = wpc_addrinfo2.getFileOffset();

			// trying to find a following JSR
			ofs2 = ofs+function.getOffset();
			bytepatterns = function.getBytePatterns();
			for (BytePattern bytecode : bytepatterns)
			{
				ofs2 = this.findJSR(ofs2, bytecode, bankseg, storeseg, wpc_addrinfo2);
				if (ofs2==0)
				{
					break;
				}
			}
			if (ofs2!=0)
			{
				ofs2 = this.findJSR(ofs2, null, bankseg, storeseg, wpc_addrinfo2);
			}
		}

		System.out.println(" B1 = Searching JSR jsrPagedFuncIndirect");
		System.out.println(" B2 = Searching JSR jsrPagedFunc");
		System.out.println(" B3 = Searching JSR jmpPagedFunc");
		System.out.println(" B4 = Searching JSR <function> with parameter bytes behind call");

		maxbank=WPC_Rom.SYSTEMBANK+1;
		for (bank=0; bank<maxbank; bank++)
		{
			TreeSet<AddrInfo> xref;

			// check bank and get data only once
			bankseg = seglist[bank];

			if (bankseg==null || bankseg.getSize()<2)
			{
				continue;
			}

			bankofs = bankseg.getOffset();
			banksize = bankseg.getSize();
			bankaddr = bankseg.getAddr();

			// check bank for storing analysis data
			storebank = bank;
			storeseg = seglist[storebank];

			// ***
			// *** B1: "JSR jsrPagedFuncIndirect"
			// ***
			// ToDo: Avoid false positive (e.g. in graphics)
			if (this.infoJsrPF_indirect!=null)
			{
				xref = this.infoJsrPF_indirect.getXRef();

				// search for "JSR jsrPagedFuncIndirect" in bank
				results1 = Bytes.searchBytes(this.data, bankofs, banksize, this.data_jsr_jsrpf_indirect);
				for (Integer result : results1)
				{
					ofs = result.intValue();

					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+0, null, 99999, AddrInfo.Type.CODE, "JSR jsrPagedFuncIndirect");
					xref.add(wpc_addrinfo);
					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+5, null, 0, AddrInfo.Type.CODE, "Return point of previous JSR jsrPagedFuncIndirect");
					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+3, null, 99999, AddrInfo.Type.ADDRESS, null, 2, WPC_AddrInfo.Type.PFPS, 0);
					wpc_addrinfo.addSymbolPrefix();

					wpc_addrinfos1 = wpc_addrinfo.analyseDeeper("B1", null, AddrInfo.Type.STRUCTURE, WPC_AddrInfo.Type.FPS);
					for (WPC_AddrInfo result1 : wpc_addrinfos1)
					{
						result1.analyseDeeper("B1", null, AddrInfo.Type.CODE, WPC_AddrInfo.Type.FUNCTION);
					}
				}
			}
			// ***
			// *** end "JSR jsrPagedFuncIndirect"
			// ***

			// ***
			// *** B2: "JSR jsrPagedFunc"
			// ***
			// ToDo: Avoid false positive (e.g. in graphics)
			if (this.infoJsrPF!=null)
			{
				xref = this.infoJsrPF.getXRef();

				// search for "JSR jsrPagedFunc" in bank
				results1 = Bytes.searchBytes(this.data, bankofs, banksize, this.data_jsr_jsrpf);
				for (Integer result : results1)
				{
					ofs = result.intValue();

					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+0, null, 99999, AddrInfo.Type.CODE, "JSR jsrPagedFunc");
					xref.add(wpc_addrinfo);
					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+6, null, 0, AddrInfo.Type.CODE, "Return point of previous JSR jsrPagedFunc");
					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+3, null, 99999, AddrInfo.Type.STRUCTURE, null, 3, WPC_AddrInfo.Type.FPS, 0);
					wpc_addrinfo.addSymbolPrefix();
					wpc_addrinfo.analyseDeeper("B2", null, AddrInfo.Type.CODE, WPC_AddrInfo.Type.FUNCTION);
				}
			}

			// ***
			// *** B3: "JSR jmpPagedFunc"
			// ***
			// ToDo: Avoid false positive (e.g. in graphics)
			if (this.infoJmpPF!=null)
			{
				xref = this.infoJmpPF.getXRef();

				// search for "JSR jmpPagedFunc" in bank
				results1 = Bytes.searchBytes(this.data, bankofs, banksize, this.data_jsr_jmppf);
				for (Integer result : results1)
				{
					ofs = result.intValue();

					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+0, null, 99999, AddrInfo.Type.CODE, "JSR jmpPagedFunc");
					xref.add(wpc_addrinfo);
					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+3, null, 99999, AddrInfo.Type.STRUCTURE, null, 3, WPC_AddrInfo.Type.FPS, 0);
					wpc_addrinfo.addSymbolPrefix();
					wpc_addrinfo.analyseDeeper("B3", null, AddrInfo.Type.CODE, WPC_AddrInfo.Type.FUNCTION);
				}
			}

			// ***
			// *** B4: "JSR <function>" with parameter bytes behind call
			// ***
			for (WPC_Function function : this.functions)
			{
				String registers, registers_clutched;
				String funcname;

				ofs2 = function.getParmCount();
				if (ofs2<=0)
				{
					continue;
				}
				wpc_addrinfo = function.getFunction();
				registers = function.getRegisters();
				registers_clutched = null;
				if (registers != null)
				{
					registers_clutched = registers.replaceAll(",", "");
				}

				addr = wpc_addrinfo.getSegment().convRelOfsToAddr(wpc_addrinfo.getRelOffset());
				funcname = wpc_addrinfo.getName().toString();
				xref = wpc_addrinfo.getXRef();

				// create compare array of JSR <function>
				data_jsr[0] = WPC_Rom.CODE_JSR;
				data_jsr[1] = (byte)((addr >>> 8) & Bytes.BYTEMASK);
				data_jsr[2] = (byte)(addr & Bytes.BYTEMASK);

				// search for "JSR <function>" in bank
				results1 = Bytes.searchBytes(this.data, bankofs, banksize, data_jsr);
				for (Integer result : results1)
				{
					ofs = result.intValue();

					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+0, null, 99999, AddrInfo.Type.CODE, "JSR to " + ofs2 + "-byte " + registers + " function " +  funcname);
					xref.add(wpc_addrinfo);
					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+3, registers_clutched, 0, AddrInfo.Type.BYTE, "Register " + registers, 1, WPC_AddrInfo.Type.DATA, ofs2);
					wpc_addrinfo.addSymbolPrefix();
					wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs-bankofs+3+ofs2, null, 0, AddrInfo.Type.CODE, "Return point of previous JSR");
				}
			}
		}

		// ***
		// *** B1: "JSR jsrPagedFuncIndirect" (find missing holes)
		// ***
		int tsize;
		bankseg = seglist[WPC_Rom.SYSTEMBANK];
		storeseg = seglist[WPC_Rom.SYSTEMBANK];
		tsize = WPC_AddrInfo.Type.FPS.getSize();
		ofs2 = 1;	// FPS table starts at second byte of System ROM
		System.out.println(" Searching unused entries of FPS table at System ROM start...");
		results1 = new ArrayList<Integer>();
		for (AddrInfo addrinfo : bankseg.getAddrInfos())
		{
			ofs = addrinfo.getRelOffset();
			if (ofs < 0)	// skip the stuff from RAM assigned to the virtual bank
			{
				continue;
			}

			wpc_addrinfo = (WPC_AddrInfo)addrinfo;
			if (wpc_addrinfo.getWPCType() != WPC_AddrInfo.Type.FPS)
			{
				break;
			}

			if (ofs2<ofs)
			{
				System.out.println(" ...found gap at " + this.getHexPrefix() + Numbers.toHexString((short)(bankseg.convRelOfsToAddr(ofs2))) + ", next found at " + this.getHexPrefix() + Numbers.toHexString((short)bankseg.convRelOfsToAddr(ofs)));

				while (ofs2<ofs)
				{
					if ((ofs2+tsize)<=ofs)
					{
						results1.add(ofs2);
					}
					ofs2 += tsize;
				}
			}

			ofs2 = ofs+tsize;
		}
		for (Integer result : results1)
		{
			ofs = result.intValue();
			wpc_addrinfo = new WPC_AddrInfo(storeseg, ofs, null, 99999, AddrInfo.Type.STRUCTURE, null, 3, WPC_AddrInfo.Type.FPS, 0);
			wpc_addrinfo.addSymbolPrefix();
			wpc_addrinfo.analyseDeeper("B1", null, AddrInfo.Type.CODE, WPC_AddrInfo.Type.FUNCTION);
		}

		if (err)
		{
			System.out.println(" These errors could be in the ROM itself or raised by my program logic (=false positive).");
			System.out.println(" If you think my program logic is the cause, then please contact me through my website, send the error protocol and state the ROM and parameters you used. Thanks Maddes.");
		}
	}

	public int findJSR(int ofs, BytePattern bytecode, WPC_Segment bankseg, WPC_Segment storeseg, WPC_AddrInfo wpc_addrinfo2)
	{
		ArrayList<Integer> results;
		int relofs, addr;
		WPC_AddrInfo wpc_addrinfo;
		boolean docontinue;

		while(this.data[ofs]==WPC_Rom.CODE_JSR)	// JSR is following
		{
			// skip special processed functions
			if (this.data_jsr_jsrpf_indirect!=null)
			{
				results = Bytes.searchBytes(this.data, ofs, data_jsr_jsrpf_indirect.length, data_jsr_jsrpf_indirect);
				if (results.size()>0)
				{
					ofs+=data_jsr_jsrpf_indirect.length+2;
					continue;
				}
			}
			if (this.data_jsr_jsrpf!=null)
			{
				results = Bytes.searchBytes(this.data, ofs, data_jsr_jsrpf.length, data_jsr_jsrpf);
				if (results.size()>0)
				{
					ofs+=data_jsr_jsrpf.length+3;
					continue;
				}
			}
			if (this.data_jsr_jmppf!=null)
			{
				results = Bytes.searchBytes(this.data, ofs, data_jsr_jmppf.length, data_jsr_jmppf);
				if (results.size()>0)
				{
					ofs = 0;
					break;	// end of function
				}
			}

			addr = Shorts.intUnsignedValue(Bytes.getShort(this.data, ofs+1));

			docontinue = false;
			for (WPC_Function function : this.functions)
			{
				if (addr==function.getAddress())
				{
					ofs+=3+function.getParmCount();
					docontinue = true;
					break;
				}
			}
			if (docontinue)
			{
				continue;
			}

			// unknown function found
			if (addr>=WPC_Rom.SYSTEMADDR)
			{
				relofs = bankseg.convAddrToRelOfs(addr);
				wpc_addrinfo = new WPC_AddrInfo(storeseg, relofs, null, 99999, AddrInfo.Type.CODE, null, 0, WPC_AddrInfo.Type.FUNCTION, 0);
				wpc_addrinfo.getXRef().add(wpc_addrinfo2);
				wpc_addrinfo.addSymbolPrefix();
			}
			ofs+=3;
			break;
		}

		if (bytecode==null)
		{
			ofs = 0;
		}

		if (ofs>0)
		{
			results = Bytes.searchBytes(this.data, ofs, bytecode.getBytePattern().length, bytecode.getBytePattern());
			if (results.size()>0)
			{
				ofs += bytecode.getBytePattern().length;
				ofs += bytecode.getPostOffset();
			}
			else
			{
				ofs = 0;
			}
		}

		return ofs;
	}


	@Override
	public void createDASMxFiles() throws Exception
	{
		String filename;

		super.createDASMxFiles();

		filename = this.createDASMxTopFile();
		if (filename!=null)
		{
			System.out.println(" Created " + filename);
			System.out.println(" !!! DON'T FORGET TO ACTIVATE THE CORRECT WPC SYMBOL FILE!!!");
		}
	}

	public String createDASMxTopFile() throws Exception
	{
		String filename;
		PrintWriter textfile;
		File file_top;

		filename = this.getFilePrefix() + "_top" + Segment.EXTENSION_DASMX;

		// Check
		file_top = new File(filename);
		if (file_top.exists())
		{
			return null;
		}

		// Open
		textfile = new PrintWriter(filename);
		// Header
		textfile.println("; proposed folder structure: WPC/<machine>/<romversion>");
		textfile.println();
		textfile.println("include \"../../apple_system_" + this.majorAppleVersion + ".sym\"");
		textfile.println("include \"../../apple_system_general.sym\"");
		textfile.println(";include \"../../wpc-???_hardware.sym\"");
		textfile.println("include \"../../wpc_hardware_general.sym\"");
		textfile.println("include \"../../mc6809.sym\"");
		textfile.println();
		textfile.println("include " + this.getFilePrefix() + "_general.sym");
		// Close
		textfile.close();

		return filename;
	}

	public void createGroupFiles() throws Exception
	{
		String filename;
		File file;
		PrintWriter textfile;
		StringBuffer temp;

		System.out.println("Creating WPC DASM Group files...");

		// set_romname.bat
		filename = "set_romname.bat";
		file = new File(filename);
		if (!file.exists())
		{
			textfile = new PrintWriter(filename);
			textfile.println("@echo off");
			textfile.println("SET ROM=" + this.getFilePrefix());
			textfile.println("SET ROMEXT=" + this.getFileExtension());
			textfile.close();
			System.out.println(" Created " + filename);
		}

		// Bug list
		filename = this.getFilePrefix() + "_bugs.txt";
		file = new File(filename);
		if (!file.exists())
		{
			textfile = new PrintWriter(filename);
			textfile.println(this.toGroupHeader());
			textfile.println();
			textfile.println("Bug List");
			textfile.println("========");
			textfile.close();
			System.out.println(" Created " + filename);
		}

		// Sound list
		filename = this.getFilePrefix() + "_sounds.txt";
		file = new File(filename);
		if (!file.exists())
		{
			textfile = new PrintWriter(filename);
			textfile.println(this.toGroupHeader());
			textfile.println();
			textfile.println("Sound List");
			textfile.println("==========");
			textfile.close();
			System.out.println(" Created " + filename);
		}

		// Bank RAM map
		filename = this.getFilePrefix() + "_dasm_ram_map.txt";
		file = new File(filename);
		if (!file.exists())
		{
			textfile = new PrintWriter(filename);
			textfile.println(this.toGroupHeader());
			textfile.println();
			textfile.println("RAM Map");
			textfile.println("=======");
			textfile.close();
			System.out.println(" Created " + filename);
		}

		// Bank files + summary
		temp = new StringBuffer();
		for (int i=0; i<this.getSegList().length; i++)
		{
			if (this.getSegList()[i]==null || this.getSegList()[i].getSize()<=0)
			{
				continue;
			}

			temp.append("Bank" + Numbers.toHexString((byte)this.getSegList()[i].getId()) + ":      unknown");
			temp.append(Rom.NEWLINE);

			filename = this.getSegList()[i].createGroupFile();
			if (filename==null)
			{
				continue;
			}

			System.out.println(" Created " + filename);
		}
		filename = this.getFilePrefix() + "_dasm_bank_summary.txt";
		file = new File(filename);
		if (!file.exists())
		{
			textfile = new PrintWriter(filename);
			textfile.println(this.toGroupHeader());
			textfile.println();
			textfile.println("Bank Summary");
			textfile.println("============");
			textfile.print(temp);
			textfile.close();
			System.out.println(" Created " + filename);
		}

		System.out.println(" Done.");
	}

	public String toGroupHeader()
	{
		StringBuffer result;

		result = new StringBuffer();

		result.append("ROM: " + this.getFilename());
		result.append(Rom.NEWLINE);
		result.append("Game version: " + this.getGameVersionString());
		result.append(Rom.NEWLINE);
		result.append("APPLE version: " + this.getAppleVersionString());

		return result.toString();
	}
}
