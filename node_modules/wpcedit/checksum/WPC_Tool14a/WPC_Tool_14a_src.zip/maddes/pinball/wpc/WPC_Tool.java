package maddes.pinball.wpc;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 22 $
$Date: 2007-09-17 12:15:32 +0200 (Mo, 17 Sep 2007) $
$Author: Dummy $

v1.4a
- adapted to updated handling for different game versioning schemes

v1.4
- added parameter "-wpcdasmgroup" for WPC DASM Group files generation
- used global revision and date to reflect changes in all related Java classes

v1.3
- fixed wrong initialization of "docrossref" variable
- added us-english parameter "-analyze"
- name of class now finally stated by function and not by a fix string
- added hint to re-activate manual symbol files after re-creation of symbol files
- bumped up version to reflect changes in WPC_Rom classes

v1.2
- added parameter for cross reference functionality
- bumped up version to reflect changes in WPC_Rom classes

v1.1
- corrected typo in call syntax
- bumped up version to reflect changes in WPC_Rom classes

v1.0
initial version
*/

/* ToDo:
- Command line parameters:
	- How to do these correctly in Java (classes from Sun?)
- Exceptions:
	- Err... normally there are no errors to handle, except the user ;)
*/

import maddes.util.Numbers;

/*
A class for handling Williams WPC ROMs
*/
final class WPC_Tool
{
	// ***
	// *** static main method
	// ***
	public static void main(String args[]) throws Exception
	{
		String filename;
		byte lowbyte;
		boolean newline, dohelp, doverbose;
		boolean dochecksum, newlowbyte, dowrite;
		boolean dosplit;
		boolean doanalyse, dodasmx, docrossref;
		boolean dogroup;
		WPC_Rom romfile;

		System.out.println("WPC Tool v1.4a (Revision " + SvnRevision.SVN_REVSTR + ", " + SvnRevision.SVN_REVDATE + ")");
		System.out.println("(c) Matthias \"Maddes\" Buecher, http://www.maddes.net/");
		System.out.println();

		newline = false;
		dohelp = false;
		doverbose = false;

		dochecksum = false;
		newlowbyte = false;
		dowrite = false;

		dosplit = false;

		doanalyse = false;
		dodasmx = false;
		docrossref = false;

		dogroup = false;

		filename = null;
		lowbyte = (byte)0;
		for (int i=0; i<args.length; i++)
		{
			if ((args[i].equalsIgnoreCase("-help")) || (args[i].equalsIgnoreCase("-?")))
			{
				dohelp = true;
			}
			else if (args[i].equalsIgnoreCase("-verbose"))
			{
				doverbose = true;
			}
			else if (args[i].equalsIgnoreCase("-checksum"))
			{
				dochecksum = true;
			}
			else if (args[i].equalsIgnoreCase("-version"))
			{
				newlowbyte = true;
				lowbyte = Numbers.parseByte(args[++i]);
			}
			else if (args[i].equalsIgnoreCase("-write"))
			{
				dowrite = true;
			}
			else if (args[i].equalsIgnoreCase("-split"))
			{
				dosplit = true;
			}
			else if (args[i].equalsIgnoreCase("-analyse"))
			{
				doanalyse = true;
			}
			else if (args[i].equalsIgnoreCase("-analyze"))
			{
				doanalyse = true;
			}
			else if (args[i].equalsIgnoreCase("-dasmx"))
			{
				doanalyse = true;
				dodasmx = true;
			}
			else if (args[i].equalsIgnoreCase("-xref"))
			{
				doanalyse = true;
				docrossref = true;
			}
			else if (args[i].equalsIgnoreCase("-wpcdasmgroup"))
			{
				dogroup = true;
			}
			else if (filename==null)
			{
				filename = args[i];
			}
			else
			{
				System.out.println("Parameter " + (i+1) + ": >" + args[i] + "< is unknown.");
				dohelp = true;
				newline = true;
			}
		}

		if (args.length<1 || dohelp)
		{
			if (newline)
			{
				System.out.println();
			}

			System.out.println("Syntax: java " + WPC_Tool.class.getName() + " <romfile> [-checksum [-version <low byte>] [-write]] [-split] [-analyse [-dasmx] [-xref]] [-verbose]");
			System.exit(0);
		}

		romfile = new WPC_Rom(filename);
		System.out.println(romfile);

		if (dochecksum)
		{
			System.out.println();
			// check version low byte
			if (newlowbyte)
			{
				if (lowbyte==romfile.getChecksumLowByte())
				{
					newlowbyte = false;
				}
			}
			else
			{
				lowbyte=romfile.getChecksumLowByte();
			}
			// check if necessary to write
			if (!newlowbyte && romfile.isChecksumOk())
			{
				dowrite = false;
			}

			romfile.calcChecksum(lowbyte, doverbose);
			if (dowrite)
			{
				filename = filename + ".new";
				System.out.println(" Writing " + filename + " with new calculated checksum.");
				romfile.save(filename);
			}
		}

		if (dosplit)
		{
			System.out.println();
			romfile.createSegmentFiles();
		}

		if (dogroup)
		{
			System.out.println();
			romfile.createGroupFiles();
		}

		if (doanalyse)
		{
			System.out.println();
			romfile.analyse();

			if (!(dodasmx || docrossref))
			{
				System.out.println();
				System.out.println(romfile.toAddrInfoString());
			}
			else
			{
				if (dodasmx)
				{
					System.out.println();
					romfile.createDASMxFiles();
				}
				if (docrossref)
				{
					System.out.println();
					romfile.createCrossRef();
				}
			}
		}
	}
}
