package maddes.util;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 16 $
$Date: 2007-09-06 16:32:02 +0200 (Do, 06 Sep 2007) $
$Author: maddes $
*/

import java.util.ArrayList;

public class Integers
{
	// ***
	// *** static class variables
	// ***
	public static final int INTMASK = 0xFFFFFFFF;
	public static final long INTMASKL = 0xFFFFFFFFl;

	// ***
	// *** static class methods
	// ***

	// ***
	// *** Get long value from an UNSIGNED integer
	// ***
	public static long longUnsignedValue(int value)
	{
		return (long)value & Integers.INTMASKL;
	}

	// ***
	// *** Get long values from an integer array
	// ***
	public static final long getLong(int[] ary, int ofs)
	{
		int i=0;
		return (long)( (Integers.longUnsignedValue(ary[ofs+i++]) << 32l) |  Integers.longUnsignedValue(ary[ofs+i++]) );
	}

	// ***
	// *** Search an integer array inside another integer array
	// ***
	public static ArrayList<Integer> searchIntegers(int where[], int start, int size, int what[])
	{
		int searchlength, end;
		ArrayList<Integer> result;
		int found = 0;

		searchlength = what.length;
		end = start + size - searchlength + 1;
		result = new ArrayList<Integer>();
		for (int i=start; i<end; i++)
		{
			found = i;
			for (int j=0; j<searchlength; j++)
			{
				if (where[i+j]!=what[j])
				{
					found = 0;
					break;
				}
			}
			if (found!=0)
			{
				result.add(found);
			}
		}

		return result;
	}

	// ***
	// *** Calculate a checksum for all integers in an array
	// ***
	public static long calcLongChecksum(int ary[], int start, int size)
	{
		int end;
		long sum;
		long val;

		end = start + size;
		sum = 0;
		for (int i = start; i < end; i++)
		{
			val = (long)ary[i] & Integers.INTMASKL;	// Important: Int value (0 - 4294967295)
			sum += val;
		}
		return sum;
	}

	public static long calcLongChecksum(int ary[])
	{
		return calcLongChecksum(ary, 0, ary.length);
	}

	public static int calcIntChecksum(int ary[], int start, int len)
	{
		return (int)calcLongChecksum(ary, start, len);
	}

	public static int calcIntChecksum(int ary[])
	{
		return calcIntChecksum(ary, 0, ary.length);
	}

	public static short calcShortChecksum(int ary[], int start, int len)
	{
		return (short)calcLongChecksum(ary, start, len);
	}

	public static short calcShortChecksum(int ary[])
	{
		return calcShortChecksum(ary, 0, ary.length);
	}

	public static byte calcByteChecksum(int ary[], int start, int len)
	{
		return (byte)calcLongChecksum(ary, start, len);
	}

	public static byte calcByteChecksum(int ary[])
	{
		return calcByteChecksum(ary, 0, ary.length);
	}
}
