package maddes.util;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 17 $
$Date: 2007-09-06 18:21:16 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

Creates a nice output of integral numbers as hexadecimal, octal or binary code

v1.4
- Added support for converting bytes into graphic string

v1.2
- Added support for octal and binary numbers, e.g. -1101b or -0173

v1.1
- Accept negative values, e.g. -0x01
*/

import maddes.util.Bytes;

public class Numbers
{
	// Class variables
	private static final char minusSign = '-';
	private static final char plusSign = '+';

	// ***
	// *** converts long/int/short/byte value into hex string
	// ***
	public static String toHexString(long value)
	{
		StringBuffer str;
		str = new StringBuffer(34)	// (bytes * 8 bits / bits per digit) * 2 + 2
				.append("0000000000000000")
				.append(Long.toHexString(value).toUpperCase());

		int end = str.length();
		int start = end - 16;	// bytes * 8 bits / bits per digit

		return str.substring(start, end);
	}

	public static String toHexString(int value)
	{
		StringBuffer str;
		str = new StringBuffer(34)
				.append("00000000")
				.append(Integer.toHexString(value).toUpperCase());

		int end = str.length();
		int start = end - 8;

		return str.substring(start, end);
	}

	public static String toHexString(short value)
	{
		StringBuffer str;
		str = new StringBuffer(34)
				.append("0000")
				.append(Integer.toHexString(value).toUpperCase());

		int end = str.length();
		int start = end - 4;

		return str.substring(start, end);
	}

	public static String toHexString(byte value)
	{
		StringBuffer str;
		str = new StringBuffer(34)
				.append("00")
				.append(Integer.toHexString(value).toUpperCase());

		int end = str.length();
		int start = end - 2;

		return str.substring(start, end);
	}

	// ***
	// *** converts long/int/short/byte value into octal string
	// ***
	public static String toOctalString(long value)
	{
		StringBuffer str;
		str = new StringBuffer(46)	// (bytes * 8 bits / bits per digit) * 2 + 2
				.append("0000000000000000000000")
				.append(Long.toOctalString(value).toUpperCase());

		int end = str.length();
		int start = end - 22;	// bytes * 8 bits / bits per digit

		return str.substring(start, end);
	}

	public static String toOctalString(int value)
	{
		StringBuffer str;
		str = new StringBuffer(46)
				.append("00000000000")
				.append(Integer.toOctalString(value).toUpperCase());

		int end = str.length();
		int start = end - 11;

		return str.substring(start, end);
	}

	public static String toOctalString(short value)
	{
		StringBuffer str;
		str = new StringBuffer(46)
				.append("000000")
				.append(Integer.toOctalString(value).toUpperCase());

		int end = str.length();
		int start = end - 6;

		return str.substring(start, end);
	}

	public static String toOctalString(byte value)
	{
		StringBuffer str;
		str = new StringBuffer(46)
				.append("000")
				.append(Integer.toOctalString(value).toUpperCase());

		int end = str.length();
		int start = end - 3;

		return str.substring(start, end);
	}

	// ***
	// *** converts long/int/short/byte value into octal string
	// ***
	public static String toBinaryString(long value)
	{
		StringBuffer str;
		str = new StringBuffer(130)	// (bytes * 8 bits / bits per digit) * 2 + 2
				.append("0000000000000000000000000000000000000000000000000000000000000000")
				.append(Long.toBinaryString(value).toUpperCase());

		int end = str.length();
		int start = end - 64;	// bytes * 8 bits / bits per digit

		return str.substring(start, end);
	}

	public static String toBinaryString(int value)
	{
		StringBuffer str;
		str = new StringBuffer(130)
				.append("00000000000000000000000000000000")
				.append(Integer.toBinaryString(value).toUpperCase());

		int end = str.length();
		int start = end - 32;

		return str.substring(start, end);
	}

	public static String toBinaryString(short value)
	{
		StringBuffer str;
		str = new StringBuffer(130)
				.append("0000000000000000")
				.append(Integer.toBinaryString(value).toUpperCase());

		int end = str.length();
		int start = end - 16;

		return str.substring(start, end);
	}

	public static String toBinaryString(byte value)
	{
		StringBuffer str;
		str = new StringBuffer(130)
				.append("00000000")
				.append(Integer.toBinaryString(value).toUpperCase());

		int end = str.length();
		int start = end - 8;

		return str.substring(start, end);
	}

	// ***
	// *** converts string (hex or decimal notation) into long/int/short/byte value
	// ***
	public static long parseLong(String valstr)
	{
		long vallong = 0;

		if ( valstr == null || valstr.length() == 0 )
		{
			return vallong;
		}

		// check for leading sign and remove it when present
		char sign = valstr.charAt(0);
		if (sign == minusSign || sign == plusSign)
		{
			valstr = valstr.substring(1, valstr.length());
		}
		else
		{
			sign = plusSign;
		}

		if ( valstr.length() == 0 )
		{
			return vallong;
		}


		// check for hex, binary or octal values
		int base = 10;	// decimal (default)
		if (valstr.substring(valstr.length()-1,valstr.length()).equalsIgnoreCase("b"))	// binary
		{
			base = 2;
			valstr = valstr.substring(0, valstr.length()-1);
		}
		else if (valstr.substring(valstr.length()-1,valstr.length()).equalsIgnoreCase("o"))	// octal
		{
			base = 8;
			valstr = valstr.substring(0, valstr.length()-1);
		}
		else if (valstr.substring(valstr.length()-1,valstr.length()).equalsIgnoreCase("h"))	// hex
		{
			base = 16;
			valstr = valstr.substring(0, valstr.length()-1);
		}
		else if (valstr.length() > 2 && valstr.substring(0,2).equalsIgnoreCase("0x"))	// hex
		{
			base = 16;
			valstr = valstr.substring(2, valstr.length());
		}
		else if (valstr.substring(0,1).equals("0"))	// octal
		{
			base = 8;
		}

		valstr = ((sign == minusSign) ? sign : "") + valstr.toUpperCase();
		vallong = Long.parseLong(valstr, base);

		return vallong;
	}

	public static int parseInt(String valstr)
	{
		int valint = 0;
		valint = (int)(parseLong(valstr) & Integers.INTMASKL);
		return valint;
	}

	public static short parseShort(String valstr)
	{
		short valshort = 0;
		valshort = (short)(parseLong(valstr) & Shorts.SHORTMASKL);
		return valshort;
	}

	public static byte parseByte(String valstr)
	{
		byte valbyte = 0;
		valbyte = (byte)(parseLong(valstr) & Bytes.BYTEMASKL);
		return valbyte;
	}

	// ***
	// *** converts long/int/short/byte value into gfx string
	// ***
	private static String toGfxString(long value, int length)
	{
		StringBuffer result;
		long maskBitX;
		long testBitX;

		result = new StringBuffer();

		maskBitX=1;
		for (int i=0; i<length; i++)
		{
			testBitX = value & maskBitX;
			if (testBitX != 0)
			{
				result.append('O');
			}
			else
			{
				result.append('.');
			}
			maskBitX = maskBitX << 1;
		}

		return result.toString();
	}

	public static String toGfxString(long value)
	{
		return toGfxString(value, 64);
	}

	public static String toGfxString(int value)
	{
		return toGfxString((long)value, 32);
	}

	public static String toGfxString(short value)
	{
		return toGfxString((long)value, 16);
	}

	public static String toGfxString(byte value)
	{
		return toGfxString((long)value, 8);
	}
}
