package maddes.util;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 16 $
$Date: 2007-09-06 16:32:02 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

Java always uses network byte order (big-endian order), for example Motorola uses these.
Intel machines use little-endians order (from lowest to highest byte).

These functions help you to deal with this issue.
Since Java 5 (=1.5.0) there's the class method reverseBytes() for all integral numbers

But this class also includes some more functions, especially to deal with byte arrays
*/

import java.util.ArrayList;

public class Bytes
{
	// ***
	// *** static class variables
	// ***
	public static final int BYTEMASK = 0xFF;
	public static final long BYTEMASKL = 0xFFl;

	// ***
	// *** static class methods
	// ***

	// ***
	// *** Swap bytes to convert between Big-Endian and Little-Endian
	// ***
	private static final long swapBytes(long value, int bytes)
	{
		long result = 0;
		long byteX = 0;

		for (int i=0; i<bytes; i++)
		{
			byteX = value & Bytes.BYTEMASKL;
			value = value>>>8;	//unsigned right shift one byte

			result = result<<8;	//left shift one byte
			result |= byteX;
		}
		return result;
	}

	public static final long swap(long value)
	{
		return swapBytes(value, 8);
	}

	public static final int swap(int value)
	{
		return (int)swapBytes((long)value & Integers.INTMASKL, 4);
	}

	public static final short swap(short value)
	{
		return (short)swapBytes((long)value & Shorts.SHORTMASKL, 2);
	}

	// ***
	// *** Get short/int/long value from an UNSIGNED byte
	// ***
	public static short shortUnsignedValue(byte value)
	{
		return (short)(value & Bytes.BYTEMASK);
	}

	public static int intUnsignedValue(byte value)
	{
		return value & Bytes.BYTEMASK;
	}

	public static long longUnsignedValue(byte value)
	{
		return (long)(value & Bytes.BYTEMASK);
	}

	// ***
	// *** Get short/int/long values from a byte array
	// ***
	public static final short getShort(byte[] ary, int ofs)
	{
		int i=0;
		return (short)( (Bytes.intUnsignedValue(ary[ofs+i++]) << 8) | Bytes.intUnsignedValue(ary[ofs+i++]) );
	}

	public static final int getInteger(byte[] ary, int ofs)
	{
		int i=0;
		return (int)( (Bytes.intUnsignedValue(ary[ofs+i++]) << 24) | (Bytes.intUnsignedValue(ary[ofs+i++]) << 16)
		            | (Bytes.intUnsignedValue(ary[ofs+i++]) << 8)  |  Bytes.intUnsignedValue(ary[ofs+i++]) );
	}

	public static final long getLong(byte[] ary, int ofs)
	{
		int i=0;
		return (long)( (Bytes.longUnsignedValue(ary[ofs+i++]) << 56l) | (Bytes.longUnsignedValue(ary[ofs+i++]) << 48l)
		             | (Bytes.longUnsignedValue(ary[ofs+i++]) << 40l) | (Bytes.longUnsignedValue(ary[ofs+i++]) << 32l)
		             | (Bytes.longUnsignedValue(ary[ofs+i++]) << 24l) | (Bytes.longUnsignedValue(ary[ofs+i++]) << 16l)
		             | (Bytes.longUnsignedValue(ary[ofs+i++]) << 8l)  |  Bytes.longUnsignedValue(ary[ofs+i++]) );
	}

	// ***
	// *** Search a byte array inside another byte array
	// ***
	public static ArrayList<Integer> searchBytes(byte where[], int start, int size, byte what[])
	{
		int searchlength, end;
		ArrayList<Integer> result;
		int found = 0;

		searchlength = what.length;
		end = start + size - searchlength + 1;
		result = new ArrayList<Integer>();
		for (int i=start; i<end; i++)
		{
			found = i;
			for (int j=0; j<searchlength; j++)
			{
				if (where[i+j]!=what[j])
				{
					found = 0;
					break;
				}
			}
			if (found!=0)
			{
				result.add(found);
			}
		}

		return result;
	}

	// ***
	// *** Calculate a checksum for all bytes in an array
	// ***
	public static long calcLongChecksum(byte ary[], int start, int size)
	{
		int end;
		long sum;
		long val;

		end = start + size;
		sum = 0;
		for (int i = start; i < end; i++)
		{
			val = Bytes.longUnsignedValue(ary[i]);	// Important: Byte value (0 - 255)
			sum += val;
		}
		return sum;
	}

	public static long calcLongChecksum(byte ary[])
	{
		return calcLongChecksum(ary, 0, ary.length);
	}

	public static int calcIntChecksum(byte ary[], int start, int len)
	{
		return (int)calcLongChecksum(ary, start, len);
	}

	public static int calcIntChecksum(byte ary[])
	{
		return calcIntChecksum(ary, 0, ary.length);
	}

	public static short calcShortChecksum(byte ary[], int start, int len)
	{
		return (short)calcLongChecksum(ary, start, len);
	}

	public static short calcShortChecksum(byte ary[])
	{
		return calcShortChecksum(ary, 0, ary.length);
	}

	public static byte calcByteChecksum(byte ary[], int start, int len)
	{
		return (byte)calcLongChecksum(ary, start, len);
	}

	public static byte calcByteChecksum(byte ary[])
	{
		return calcByteChecksum(ary, 0, ary.length);
	}

	// ***
	// *** Other byte functions taken from http://www.java-tutor.com/javabuch/
	// ***
	public static int rotateLeft( int v, int n )
	{
  		return (v << n) | (v >>> (32 - n));
	}

	public static int rotateRight( int v, int n )
	{
  		return (v >>> n) | (v << (32 - n));
	}

	long setBit( long n, int pos )
	{
  		return n | (1 << pos);
	}

	int setBit( int n, int pos )
	{
  		return n | (1 << pos);
	}

	short setBit( short n, int pos )
	{
  		return (short)(n | (1 << pos));
	}

	byte setBit( byte n, int pos )
	{
  		return (byte)(n | (1 << pos));
	}

	long clearBit( long n, int pos )
	{
  		return n & ~(1 << pos);
	}

	int clearBit( int n, int pos )
	{
  		return n & ~(1 << pos);
	}

	short clearBit( short n, int pos )
	{
  		return (short)(n & ~(1 << pos));
	}

	byte clearBit( byte n, int pos )
	{
  		return (byte)(n & ~(1 << pos));
	}

	long flipBit( long n, int pos )
	{
  		return n ^ (1 << pos);
	}

	int flipBit( int n, int pos )
	{
  		return n ^ (1 << pos);
	}

	short flipBit( short n, int pos )
	{
  		return (short)(n ^ (1 << pos));
	}

	byte flipBit( byte n, int pos )
	{
  		return (byte)(n ^ (1 << pos));
	}

	boolean testBit( long n, int pos )
	{
  		int mask = 1 << pos;
  		return (n & mask) == mask;
	}

	boolean testBit( int n, int pos )
	{
  		int mask = 1 << pos;
  		return (n & mask) == mask;
	}

	boolean testBit( short n, int pos )
	{
  		int mask = 1 << pos;
  		return (n & mask) == mask;
	}

	boolean testBit( byte n, int pos )
	{
  		int mask = 1 << pos;
  		return (n & mask) == mask;
	}
}
