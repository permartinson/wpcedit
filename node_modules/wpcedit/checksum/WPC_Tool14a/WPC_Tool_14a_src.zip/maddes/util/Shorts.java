package maddes.util;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 16 $
$Date: 2007-09-06 16:32:02 +0200 (Do, 06 Sep 2007) $
$Author: maddes $
*/

import java.util.ArrayList;

public class Shorts
{
	// ***
	// *** static class variables
	// ***
	public static final int SHORTMASK = 0xFFFF;
	public static final long SHORTMASKL = 0xFFFFl;

	// ***
	// *** static class methods
	// ***

	// ***
	// *** Get int/long value from an UNSIGNED short
	// ***
	public static int intUnsignedValue(short value)
	{
		return value & Shorts.SHORTMASK;
	}

	public static long longUnsignedValue(short value)
	{
		return (long)(value & Shorts.SHORTMASK);
	}

	// ***
	// *** Get int/long values from a short array
	// ***
	public static final int getInteger(short[] ary, int ofs)
	{
		int i=0;
		return (int)( (Shorts.intUnsignedValue(ary[ofs+i++]) << 16) | Shorts.intUnsignedValue(ary[ofs+i++]) );
	}

	public static final long getLong(short[] ary, int ofs)
	{
		int i=0;
		return (long)( (Shorts.longUnsignedValue(ary[ofs+i++]) << 48l) | (Shorts.longUnsignedValue(ary[ofs+i++]) << 32l)
		             | (Shorts.longUnsignedValue(ary[ofs+i++]) << 16l) |  Shorts.longUnsignedValue(ary[ofs+i++]) );
	}

	// ***
	// *** Search a short array inside another short array
	// ***
	public static ArrayList<Integer> searchShorts(short where[], int start, int size, short what[])
	{
		int searchlength, end;
		ArrayList<Integer> result;
		int found = 0;

		searchlength = what.length;
		end = start + size - searchlength + 1;
		result = new ArrayList<Integer>();
		for (int i=start; i<end; i++)
		{
			found = i;
			for (int j=0; j<searchlength; j++)
			{
				if (where[i+j]!=what[j])
				{
					found = 0;
					break;
				}
			}
			if (found!=0)
			{
				result.add(found);
			}
		}

		return result;
	}

	// ***
	// *** Calculate a checksum for all shorts in an array
	// ***
	public static long calcLongChecksum(short ary[], int start, int size)
	{
		int end;
		long sum;
		long val;

		end = start + size;
		sum = 0;
		for (int i = start; i < end; i++)
		{
			val = (long)ary[i] & Shorts.SHORTMASKL;	// Important: Short value (0 - 65535)
			sum += val;
		}
		return sum;
	}

	public static long calcLongChecksum(short ary[])
	{
		return calcLongChecksum(ary, 0, ary.length);
	}

	public static int calcIntChecksum(short ary[], int start, int len)
	{
		return (int)calcLongChecksum(ary, start, len);
	}

	public static int calcIntChecksum(short ary[])
	{
		return calcIntChecksum(ary, 0, ary.length);
	}

	public static short calcShortChecksum(short ary[], int start, int len)
	{
		return (short)calcLongChecksum(ary, start, len);
	}

	public static short calcShortChecksum(short ary[])
	{
		return calcShortChecksum(ary, 0, ary.length);
	}

	public static byte calcByteChecksum(short ary[], int start, int len)
	{
		return (byte)calcLongChecksum(ary, start, len);
	}

	public static byte calcByteChecksum(short ary[])
	{
		return calcByteChecksum(ary, 0, ary.length);
	}
}
