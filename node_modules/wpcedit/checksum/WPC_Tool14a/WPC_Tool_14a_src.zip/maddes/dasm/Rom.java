package maddes.dasm;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 17 $
$Date: 2007-09-06 18:21:16 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

v1.4
- added lowercase getters for filename data

v1.2
- added cross reference methods
- added methods to get a hex prefix and segment separator defined by the rom
- using the hex prefix defined by the rom

v1.1
- added a method to check if a segment id exists

v1.0
initial version
*/

import java.io.RandomAccessFile;
import java.io.PrintWriter;
import java.util.Collections;
import maddes.util.Numbers;

public abstract class Rom
{
	// ***
	// *** static class variables
	// ***
	public static final String NEWLINE;
	public static final String EXTENSION_XREF;
	public static final String HEXPREFIX;
	public static final String SEGSEPARATOR;

	// ***
	// *** static class "constructor"
	// ***
	static
	{
		NEWLINE = System.getProperty("line.separator");
		EXTENSION_XREF = "_xref.csv";
		HEXPREFIX = "0x";
		SEGSEPARATOR = ":";
	}

	// ***
	// *** static class methods
	// ***

	// ***
	// *** object variables
	// ***
	private final String filename;
	public byte data[];
	// segments
	private final Segment seglist[];
	// splitted filename for creating files (segments, symbols, etc.)
	private final String fileprefix;
	private final String fileextension;

	private boolean analysed;

	// ***
	// *** object constructors
	// ***
	public Rom(String filename, Segment seglist[]) throws Exception
	{
		this.filename = filename;
		// split filename
		int ofs = filename.lastIndexOf('.');
		if (ofs < 0)
		{
			fileprefix = filename;
			fileextension = "";
		}
		else
		{
			fileprefix = filename.substring(0,ofs);
			fileextension = filename.substring(ofs);
		}

		this.load();

		this.seglist = seglist;

		this.analysed = false;
	}

	public Rom(String filename, int lastseg) throws Exception
	{
		this(filename, new Segment[lastseg+1]);
	}

	public Rom(String filename) throws Exception	// for unsegmented ROMs
	{
		this(filename, new Segment[1]);
		this.seglist[0] = new Segment(0, this, 0, this.data.length, 0);
	}

	// ***
	// *** object setter/getter
	// ***
	public Segment[] getSegList()
	{
		return this.seglist;
	}

	public String getFilename()
	{
		return this.filename;
	}

	public String getFilenameLower()
	{
		return this.filename.toLowerCase();
	}

	public String getFilePrefix()
	{
		return this.fileprefix;
	}

	public String getFilePrefixLower()
	{
		return this.fileprefix.toLowerCase();
	}

	public String getFileExtension()
	{
		return this.fileextension;
	}

	public String getFileExtensionLower()
	{
		return this.fileextension.toLowerCase();
	}

	public void setAnalysed()
	{
		this.analysed = true;
	}

	public boolean isAnalysed()
	{
		return this.analysed;
	}

	public String getHexPrefix()
	{
		return Rom.HEXPREFIX;
	}

	public String getSegmentSeparator()
	{
		return Rom.SEGSEPARATOR;
	}

	// ***
	// *** object methods
	// ***
	private void load() throws Exception
	{
		RandomAccessFile datafile;

		datafile = new RandomAccessFile(this.getFilename(), "r");
		this.data = new byte[(int)datafile.length()];
		datafile.read(this.data);
		datafile.close();
	}

	public void save(String filename) throws Exception
	{
		RandomAccessFile datafile;

		datafile = new RandomAccessFile(filename, "rw");
		datafile.write(this.data);
		datafile.close();
	}

	protected String createFilename(String extension)
	{
		String prefix;

		prefix = this.getFilePrefix();
		if (prefix==null || prefix.equals(""))
		{
			return null;
		}
		return prefix + extension;
	}

	public void createSegmentFiles() throws Exception
	{
		System.out.println("Creating segment files...");
		if (this.getSegList().length<=1)	// unsegmented ROM, not necessary
		{
			return;
		}

		for (int i=0; i<this.getSegList().length; i++)
		{
			if (this.getSegList()[i]==null || this.getSegList()[i].getSize()<=0)
			{
				continue;
			}

			String filename;
			filename = this.getSegList()[i].createSegmentFile();
			if (filename==null)
			{
				continue;
			}

			System.out.println(" Created " + filename);
		}
	}

	protected abstract void analyseDeeper();

	public void analyse()
	{
		if (this.isAnalysed())
		{
			return;
		}
		this.setAnalysed();

		System.out.println("Analysing ROM...");

		this.analyseDeeper();

		for (int i=0; i<this.getSegList().length; i++)
		{
			if (this.getSegList()[i]==null)
			{
				continue;
			}

		}

		System.out.println("Analysing done.");
	}

	public void createDASMxFiles() throws Exception
	{
		System.out.println("Creating DASMx symbol files...");

		for (int i=0; i<this.getSegList().length; i++)
		{
			if (this.getSegList()[i]==null)
			{
				continue;
			}

			String filename;
			filename = this.getSegList()[i].createDASMxFile();
			if (filename==null)
			{
				continue;
			}

			System.out.println(" Created " + filename);
		}
	}

	public String toAddrInfoString()
	{
		StringBuffer result;
		String addrinfolist;
		boolean	newline;

		result = new StringBuffer();
		newline = false;
		for (int i=0; i<this.getSegList().length; i++)
		{
			if (this.getSegList()[i]==null)
			{
				continue;
			}

			if (this.getSegList().length>1)	// segmented ROM, display segment too
			{
				if (newline)
				{
					result.append(Rom.NEWLINE);
				}

				result.append(this.getSegList()[i]);
				newline = true;
			}

			addrinfolist = this.getSegList()[i].toAddrInfoString();
			if (addrinfolist!=null && !addrinfolist.equals(""))
			{
				if (newline)
				{
					result.append(Rom.NEWLINE);
				}

				result.append(addrinfolist);
				newline = true;
			}
		}
		return result.toString();
	}

	public String toSegmentList()
	{
		if (this.getSegList().length<=1)	// unsegmented ROM, not necessary
		{
			return null;
		}

		StringBuffer result;
		boolean	newline;

		result = new StringBuffer();
		newline = false;
		for (int i=0; i<this.getSegList().length; i++)
		{
			if (this.getSegList()[i]==null)
			{
				continue;
			}

			if (newline)
			{
				result.append(Rom.NEWLINE);
			}

			result.append(this.getSegList()[i]);
			newline = true;
		}
		return result.toString();
	}

	// disassemble as text graphic
	public String toGfxString(int ofs, int len, int bytes_per_row, String separator1, String separator2, int addrofs, char zero, char one)
	{
		StringBuffer result;
		int rest;
		int i, j, k;
		int idxGfx;
		byte value;
		char charGfx[] = new char[bytes_per_row*8];
		int maskBitX;
		int testBitX;

		result = new StringBuffer();

		for (i=0; i<len; )
		{
			// new line
			if (i>0)	// not first line
			{
				result.append(Rom.NEWLINE);
			}
			if (separator1!=null && !separator1.equals(""))
			{
				result.append(separator1);
			}
			if (addrofs>=0)
			{
				result.append(this.getHexPrefix() + Numbers.toHexString(addrofs) + ": ");	// memory address
			}
			else
			{
				result.append(this.getHexPrefix() + Numbers.toHexString(ofs) + ": ");	// data offset
			}

			idxGfx=0;
			for (j=0; (j<bytes_per_row) && (i<len); j++)
			{
				value = this.data[ofs];
				result.append(Numbers.toHexString(value) + " ");
				maskBitX=1;
				for (k=0; k<8; k++, idxGfx++)
				{
					testBitX = value & maskBitX;
					if (testBitX != 0)
					{
						charGfx[idxGfx] = 'O';
					}
					else
					{
						charGfx[idxGfx] = '.';
					}
					maskBitX = maskBitX << 1;
				}
				i++;
				ofs++;
				if (addrofs>=0)
				{
					addrofs++;
				}
			}
			if (separator2!=null && !separator2.equals(""))
			{
				result.append(separator2);
			}
			else
			{
				result.append("=");
			}
			result.append(" ");
			for (j=0; j<idxGfx; j++)
			{
				result.append(charGfx[j]);
			}
		}

		return result.toString();
	}

	public String toGfxString(int ofs, int len, int bytes_per_row, String separator1, String separator2, int addrofs)
	{
		return this.toGfxString(ofs, len, bytes_per_row, separator1, separator2, addrofs, '.', 'O');
	}

	public String toGfxString(int ofs, int len, int bytes_per_row, String separator1, String separator2)
	{
		return this.toGfxString(ofs, len, bytes_per_row, separator1, separator2, -1);
	}

	@Override
	public String toString()
	{
		StringBuffer result;

		result = new StringBuffer();
		result.append("File " + this.getFilename() + " contains " + this.data.length + " bytes");
		if (this.getSegList().length>1)	// segmented ROM
		{
			result.append(" and has " + this.getSegList().length + " segments");
			result.append(Rom.NEWLINE);
			result.append("Prefix is ");
			result.append(this.getFilePrefix());
			result.append(Rom.NEWLINE);
			result.append("Extension is ");
			result.append(this.getFileExtension());
		}
		return result.toString();
	}

	public int checkSegmentExists(int id, StringBuffer comment)
	{
		int	newid;

		newid = id;

		// check if bank exists in ROM
		if (this.seglist[newid]==null)
		{
			newid = 0;
			if (comment!=null)
			{
				comment.append(" (WEIRD NON-EXISTANT SEGMENT)");
			}
		}

		return newid;
	}

	public void createCrossRef() throws Exception
	{
		String filename;
		PrintWriter textfile;
		String temp;

		System.out.println("Creating Cross Reference file...");

		filename = this.createFilename(Rom.EXTENSION_XREF);
		if(filename==null || filename.equals(""))
		{
			return;
		}

		// Open
		textfile = new PrintWriter(filename);
		// Header
		textfile.println("\"Cross reference of " + this.getFilename() + "\";");
		textfile.println("");
		// Cross Reference
		this.createCrossRefDeeper(textfile);
		// Close
		textfile.close();

		System.out.println(" Created " + filename);
	}

	protected void createCrossRefDeeper(PrintWriter textfile) throws Exception
	{
		String xrefString;

		for (AddrInfo.Type type : AddrInfo.Type.values())
		{
			if (!(type.inXRef()))
			{
				continue;
			}

			textfile.println("\"" + type + ":\";");
			textfile.println("\"T/R\";\"Name\";\"Address\";\"File Ofs\";\"Segment Ofs\";");

			for (int i=0; i<this.seglist.length; i++)
			{
				if (this.seglist[i]==null)
				{
					continue;
				}

				for (AddrInfo addrinfo : this.seglist[i].getAddrInfos())
				{
					if (addrinfo.getType() != type)
					{
						continue;
					}

					xrefString = addrinfo.createCrossRef();
					if (xrefString==null || xrefString.equals(""))
					{
						continue;
					}

					textfile.println(addrinfo.createCrossRef());
				}
			}

			textfile.println();
		}
	}
}
