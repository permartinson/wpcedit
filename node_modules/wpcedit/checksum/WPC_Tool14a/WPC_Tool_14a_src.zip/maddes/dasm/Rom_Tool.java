package maddes.dasm;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 17 $
$Date: 2007-09-06 18:21:16 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

v1.3
- name of class now finally stated by function and not by a fixed string
- bumped up version to reflect changes in DASM classes

v1.2
- corrected typo in call syntax
- using the hex prefix defined by the rom
- bumped up version to reflect changes in Rom classes

v1.0
initial version
*/

/* ToDo:
- Command line parameters:
  - How to do these correctly in Java (classes from Sun?)
- Exceptions:
  - Err... normally there are no errors to handle, except the user ;)
*/

import maddes.util.Numbers;

/*
A class for handling ROMs
*/
final class Rom_Tool extends maddes.dasm.Rom
{
	// ***
	// *** object constructors
	// ***
	public Rom_Tool(String filename) throws Exception
	{
		super(filename);
	}

	// ***
	// *** object methods
	// ***
	@Override
	protected void analyseDeeper()
	{
	}

	// ***
	// *** static main method
	// ***
	public static void main(String args[]) throws Exception
	{
		String filename;
		boolean newline, dohelp, doverbose;
		boolean dogfx;
		int ofs, len, bytes_per_row;
		Rom_Tool romfile;

		System.out.println("ROM Tool v1.4");
		System.out.println("(c) Matthias \"Maddes\" Buecher, http://www.maddes.net/");
		System.out.println();

		newline = false;
		dohelp = false;
		doverbose = false;

		dogfx = false;

		filename = null;
		ofs = 0;
		len = 0;
		bytes_per_row = 0;
		for (int i=0; i<args.length; i++)
		{
			if ((args[i].equalsIgnoreCase("-help")) || (args[i].equalsIgnoreCase("-?")))
			{
				dohelp = true;
			}
			else if (args[i].equalsIgnoreCase("-verbose"))
			{
				doverbose = true;
			}
			else if (args[i].equalsIgnoreCase("-gfx"))
			{
				dogfx = true;
				ofs = Numbers.parseInt(args[++i]);
				len = Numbers.parseInt(args[++i]);
				bytes_per_row = Numbers.parseInt(args[++i]);

				if ( ( ofs < 0 )
				|| ( len <= 0 )
				|| ( bytes_per_row <= 0 ) )
				{
					System.out.println("ERROR: Only positive values are allowed for the file offset and byte parameters");
					dohelp = true;
					newline = true;
				}
			}
			else if (filename==null)
			{
				filename = args[i];
			}
			else
			{
				System.out.println("Parameter " + (i+1) + ": >" + args[i] + "< is unknown.");
				dohelp = true;
				newline = true;
			}
		}

		if (args.length<1 || dohelp)
		{
			if (newline)
			{
				System.out.println();
			}

			System.out.println("Syntax: java " + Rom_Tool.class.getName() + " <romfile> [-gfx <file offset> <length> <bytes per row>] [-verbose]");
			System.exit(0);
		}

		romfile = new Rom_Tool(filename);
		System.out.println(romfile);

		if (dogfx)
		{
			System.out.println();
			System.out.println("File offset: " + Rom.HEXPREFIX + Numbers.toHexString(ofs));
			System.out.println("Length: " + len);
			System.out.println("Bytes per row: " + bytes_per_row);
			System.out.println();
			System.out.println(romfile.toGfxString(ofs, len, bytes_per_row, null, null));
		}
	}
}
