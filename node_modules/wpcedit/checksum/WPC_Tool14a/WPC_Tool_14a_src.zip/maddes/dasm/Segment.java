package maddes.dasm;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 17 $
$Date: 2007-09-06 18:21:16 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

v1.2
- added an id string
  with corresponding getter/setter methods
- using the hex prefix defined by the rom

v1.0
initial version
*/

import java.io.RandomAccessFile;
import java.io.PrintWriter;
import java.util.TreeSet;
import maddes.util.Numbers;

public class Segment implements java.lang.Comparable<Segment>
{
	// ***
	// *** static class variables
	// ***
	public static final String EXTENSION_DASMX;

	// ***
	// *** static class "constructor"
	// ***
	static
	{
		EXTENSION_DASMX = ".sym";
	}

	// ***
	// *** static class methods
	// ***

	// ***
	// *** object variables
	// ***
	private final int id;
	private final Rom rom;
	private final int ofs;
	private final int size;
	private final int addr;
	private final TreeSet<AddrInfo> addrinfos;

	private String idString;

	// ***
	// *** object constructors
	// ***
	public Segment(int id, Rom rom, int ofs, int size, int addr, TreeSet<AddrInfo> addrinfos)
	{
		this.id = id;
		this.rom = rom;
		this.ofs = ofs;
		this.size = size;
		this.addr = addr;
		this.addrinfos = addrinfos;
		this.idString = rom.getHexPrefix() + Numbers.toHexString(id);
	}

	public Segment(int id, Rom rom, int ofs, int size, int addr)
	{
		this(id, rom, ofs, size, addr, new TreeSet<AddrInfo>());
	}

	// ***
	// *** object setter/getter
	// ***
	public int getId()
	{
		return this.id;
	}

	public String getIdString()
	{
		return this.idString;
	}

	protected void setIdString(String idstring)
	{
		this.idString = idstring;
	}

	public Rom getRom()
	{
		return this.rom;
	}

	public int getOffset()
	{
		return this.ofs;
	}

	public int getSize()
	{
		return this.size;
	}

	public int getAddr()
	{
		return this.addr;
	}

	public TreeSet<AddrInfo> getAddrInfos()
	{
		return this.addrinfos;
	}

	// ***
	// *** object equality/order
	// ***
	public int compareTo(Segment other)
	{
		int thisId = this.getId();
		int otherId = other.getId();
		return (thisId<otherId ? -1 : (thisId==otherId ? 0 : 1));
	}

	// ***
	// *** object methods
	// ***
	@Override
	public String toString()
	{
		return "Segment " + this.getId() + ": Offset " + this.getRom().getHexPrefix() + Numbers.toHexString(this.getOffset()) + ", Size " + this.getRom().getHexPrefix() + Numbers.toHexString(this.getSize()) + ", Address " + this.getRom().getHexPrefix() + Numbers.toHexString(this.getAddr());
	}

	public int convOfsToRelOfs(int ofs)
	{
		return ofs - this.getOffset();
	}

	public int convAddrToRelOfs(int addr)
	{
		return addr - this.getAddr();
	}

	public int convRelOfsToOfs(int relofs)
	{
		return this.getOffset() + relofs;
	}

	public int convRelOfsToAddr(int relofs)
	{
		return this.getAddr() + relofs;
	}

	public int convOfsToAddr(int ofs)
	{
		return this.convRelOfsToAddr(this.convOfsToRelOfs(ofs));
	}

	public int convAddrToOfs(int addr)
	{
		return this.convRelOfsToOfs(this.convAddrToRelOfs(addr));
	}

	protected String createFilename(String extension)
	{
		String prefix;
		String filename;

		if (this.getRom()==null)
		{
			return null;
		}

		prefix = this.getRom().getFilePrefix();
		if (prefix==null || prefix.equals(""))
		{
			return null;
		}
		return prefix + "_" + Numbers.toHexString(this.getOffset()) + extension;
	}

	public String createSegmentFile() throws Exception
	{
		String extension;
		String filename;
		RandomAccessFile datafile;

		if (this.getRom()==null)
		{
			return null;
		}

		if (this.getSize()<=0)
		{
			return null;
		}

		if (this.getOffset()>=this.getRom().data.length)
		{
			return null;
		}

		extension = this.getRom().getFileExtension();
		filename = this.createFilename(extension);
		if (filename==null || filename.equals(""))
		{
			return null;
		}

		datafile = new RandomAccessFile(filename, "rw");
		datafile.write(this.getRom().data, this.getOffset(), this.getSize());
		datafile.close();

		return filename;
	}

	public String toDASMxHeader()
	{
		return "org 0x" + Numbers.toHexString(this.getAddr());	//fix format
	}

	public String createDASMxFile() throws Exception
	{
		String filename;
		PrintWriter textfile;
		String temp;

		filename = this.createFilename(Segment.EXTENSION_DASMX);
		if(filename==null || filename.equals(""))
		{
			return null;
		}

		// Open
		textfile = new PrintWriter(filename);
		// Header
		temp = this.toDASMxHeader();
		if (temp!=null && !temp.equals(""))
		{
			textfile.println(temp);
		}
		// AddrInfos
		for (AddrInfo addrinfo : this.getAddrInfos())
		{
			textfile.println(addrinfo.toDASMxString());
		}
		// Close
		textfile.close();

		return filename;
	}

	public String toAddrInfoString()
	{
		StringBuffer result;
		boolean	newline;

		result = new StringBuffer();
		newline = false;
		for (AddrInfo addrinfo : this.getAddrInfos())
		{
			if (newline)
			{
				result.append(Rom.NEWLINE);
			}

			result.append(" " + addrinfo);
			newline = true;
		}

		return result.toString();
	}
}
