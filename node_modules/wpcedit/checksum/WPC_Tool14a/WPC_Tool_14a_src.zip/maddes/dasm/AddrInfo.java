package maddes.dasm;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 17 $
$Date: 2007-09-06 18:21:16 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

v1.3
- added prefix symbol to sub-class Type
- defined prefix "c" for code
- implemented basename and name for multiple reasons
- added methods to add prefixes to name of addr info
- added new signature for getFullAddress to work with a given separator

v1.2
- added cross reference code
  build by an added TreeSet
- added a flag in types if they shall be included in cross references
  with corresponding getter method
- added an address string
  with corresponding getter/setter methods
- added a method to get a full address string including segment id string
- using the hex prefix defined by the rom
- made basename non-final
  with corresponding setter method

v1.1
- added ordinal number for sorting/prioritizing AddrInfos for the same address
- made comment a string buffer, so it can be changed during analysis
- changed name to a basename and a method to get its complete name, this way
  sub-classes can extend the name format to their liking
- removed typename, this can be done in sub-classes
- updated compareTo/equals methods to class changes

v1.0
initial version
*/

import maddes.util.Numbers;
import java.util.TreeSet;

public class AddrInfo implements java.lang.Comparable<AddrInfo>
{
	// ***
	// *** static class variables
	// ***
	public static enum Type
	{
		CODE(true, "c"),	// define functions and jump points by giving this address a name
		BYTE(false),
		WORD(false),	// = 2 bytes
		INT(false),	// = 4 bytes
		LONG(false),	// = 8 bytes
		STRING(false),	// define size in bytes
		STRUCTURE(false),	// mixture of different types, define size in bytes, for tables also use count
		VECTOR(false),	// pointer to code, size depends on CPU
		ADDRESS(false);	// pointer to data, size depends on CPU

		private boolean xref;
		private String prefixSymbol;

		private Type(boolean xref, String prefixSymbol)
		{
			this.xref = xref;
			this.prefixSymbol = prefixSymbol;
		}

		private Type(boolean xref)
		{
			this.xref = xref;
			this.prefixSymbol = this.name().toLowerCase();
		}

		private Type()
		{
			this(false);
		}

		public boolean inXRef()
		{
			return this.xref;
		}

		public String getPrefixSymbol()
		{
			return this.prefixSymbol;
		}
	}

	// ***
	// *** static class "constructor"
	// ***

	// ***
	// *** static class methods
	// ***

	// ***
	// *** object variables
	// ***
	private final Segment seg;
	private final int relofs;	// offset inside segment
	private String basename;	// extra name for this address (e.g. function name, etc.)
	private StringBuffer name;	// complete name for this address (e.g. type + address + basename)
	private final int ordinal;	// sort order

	private final AddrInfo.Type type;	// CODE or some data
	private int size;		// size of data in bytes (e.g. string, structure, etc.)
	private int count;	// count of data when data table (0 means no table)

	private StringBuffer comment;

	private final TreeSet<AddrInfo> xref;

	private String addrString;

	// ***
	// *** object constructors
	// ***
	public AddrInfo(Segment seg, int relofs, String basename, int ordinal, AddrInfo.Type type, String comment, int size, int count, TreeSet<AddrInfo> xref)	// typical for complicated data
	{
		this.seg = seg;
		this.relofs = relofs;
		this.basename = basename;
		this.name = new StringBuffer();
		if (basename!=null)
		{
			this.name.append(basename);
		}
		this.ordinal = ordinal;
		this.type = type;
		this.xref = xref;
		this.comment = new StringBuffer();
		if (comment!=null)
		{
			this.comment.append(comment);
		}
		this.addrString = seg.getRom().getHexPrefix() + Numbers.toHexString(seg.convRelOfsToAddr(relofs));

		if (type == AddrInfo.Type.CODE)
		{
			this.size = 0;
			this.count = 0;
		}
		else
		{
			this.count = count;

			if (type == AddrInfo.Type.BYTE)
			{
				this.size = 1;
			}
			else if (type == AddrInfo.Type.WORD)
			{
				this.size = 2;
			}
			else if (type == AddrInfo.Type.INT)
			{
				this.size = 4;
			}
			else if (type == AddrInfo.Type.LONG)
			{
				this.size = 8;
			}
			else
			{
				this.size = size;
			}
		}

		boolean result = this.seg.getAddrInfos().add(this);
	}

	public AddrInfo(Segment seg, int relofs, String basename, int ordinal, AddrInfo.Type type, String comment, int size, int count)	// typical for complicated data
	{
		this(seg, relofs, basename, ordinal, type, comment, size, count, new TreeSet<AddrInfo>());
	}

	public AddrInfo(Segment seg, int relofs, String basename, int ordinal, AddrInfo.Type type, String comment)	// typical for code and simple data
	{
		this(seg, relofs, basename, ordinal, type, comment, 0, 0, new TreeSet<AddrInfo>());
	}

	public AddrInfo(Segment seg, int relofs, AddrInfo.Type type)	// typical for unknown code and unknown data
	{
		this(seg, relofs, null, 99999, type, null);
	}

	// ***
	// *** object setter/getter
	// ***
	public Segment getSegment()
	{
		return this.seg;
	}

	public int getRelOffset()
	{
		return this.relofs;
	}

	public int getOrdinal()
	{
		return this.ordinal;
	}

	public String getBaseName()
	{
		return this.basename;
	}

	public StringBuffer getName()
	{
		return this.name;
	}

	public AddrInfo.Type getType()
	{
		return this.type;
	}

	public StringBuffer getComment()
	{
		return this.comment;
	}

	public int getSize()
	{
		return this.size;
	}

	public void setSize(int size)
	{
		if (this.isSizeChangeable())
		{
			this.size = size;
		}
	}

	public int getCount()
	{
		return this.count;
	}

	public void setCount(int count)
	{
		this.count = count;
	}

	public TreeSet<AddrInfo> getXRef()
	{
		return this.xref;
	}

	public String getAddrString()
	{
		return this.addrString;
	}

	protected void setAddrString(String addrstring)
	{
		this.addrString = addrstring;
	}

	// ***
	// *** object equality/order
	// ***
	@Override
	public boolean equals(Object obj)
	{
		if (obj instanceof AddrInfo)
		{
				AddrInfo other;
				boolean result;

				other = (AddrInfo)obj;
				result = (this.seg==other.seg)
						 && (this.relofs==other.relofs)
						 && (this.ordinal==other.ordinal)
						 && (this.type==other.type)
						 && (this.size==other.size)
						 && (this.count==other.count);

				// Basename
				if (result)
				{
					String thisstr, otherstr;

					thisstr = this.getBaseName();
					otherstr = other.getBaseName();

					if (thisstr==otherstr)
					{
						result = true;
					}
					else if (thisstr==null || otherstr==null)
					{
						result = false;
					}
					else
					{
						result = thisstr.equals(otherstr);
					}
				}

				return result;
		}
		return super.equals(obj);
	}

	public int compareTo(AddrInfo other)
	{
		int result;

		if (other==this)
		{
			return 0;
		}

		if (other==null)
		{
			return 1;
		}

		// Segment
		result = this.getSegment().compareTo(other.getSegment());

		// Offset
		if (result==0)
		{
			int thisRelOfs, otherRelOfs;

			thisRelOfs = this.getRelOffset();
			otherRelOfs = other.getRelOffset();
			result = (thisRelOfs<otherRelOfs ? -1 : (thisRelOfs==otherRelOfs ? 0 : 1));
		}

		// Ordinal
		if (result==0)
		{
			int thisOrdinal, otherOrdinal;

			thisOrdinal = this.getOrdinal();
			otherOrdinal = other.getOrdinal();
			result = (thisOrdinal<otherOrdinal ? -1 : (thisOrdinal==otherOrdinal ? 0 : 1));
		}

		// Type
		if (result==0)
		{
			AddrInfo.Type thistype, othertype;

			thistype = this.getType();
			othertype = other.getType();

			if (thistype==othertype)
			{
				result = 0;
			}
			else if (thistype==null)
			{
				result = -1;
			}
			else if (othertype==null)
			{
				result = 1;
			}
			else
			{
				result = thistype.compareTo(othertype);
			}
		}

		// Basename
		if (result==0)
		{
			String thisstr, otherstr;

			thisstr = this.getBaseName();
			otherstr = other.getBaseName();

			if (thisstr==otherstr)
			{
				result = 0;
			}
			else if (thisstr==null)
			{
				result = -1;
			}
			else if (otherstr==null)
			{
				result = 1;
			}
			else
			{
				result = thisstr.compareTo(otherstr);
			}
		}

		// Size
		if (result==0)
		{
			int thisSize, otherSize;

			thisSize = this.getSize();
			otherSize = other.getSize();
			result = (thisSize<otherSize ? -1 : (thisSize==otherSize ? 0 : 1));
		}

		// Count
		if (result==0)
		{
			int thisCount, otherCount;

			thisCount = this.getCount();
			otherCount = other.getCount();
			result = (thisCount<otherCount ? -1 : (thisCount==otherCount ? 0 : 1));
		}

		return result;
	}

	// ***
	// *** object methods
	// ***
	@Override
	public String toString()
	{
		return "Offset " + this.getSegment().getRom().getHexPrefix() + Numbers.toHexString(this.getRelOffset()) + " = (Name " + this.getName() + ", Type " + this.getType() + ", Size " + this.getSize() + ')';
	}

	public String createSymbolPrefix()
	{
		StringBuffer result;
		AddrInfo.Type type;

		result = new StringBuffer();

		type = this.getType();
		if (type!=null)
		{
			result.append(type.getPrefixSymbol());
		}
		else
		{
			result.append("label");
		}
		result.append("_");
		result.append(this.getFullAddress("_"));

		return result.toString();
	}

	public void addSymbolPrefix()
	{
		StringBuffer name;
		String prefix;

		prefix = this.createSymbolPrefix();
		if (prefix==null || prefix.equals(""))
		{
			return;
		}

		name = this.getName();
		if (name.length()>0)
		{
			name.insert(0, "_");
		}
		name.insert(0, prefix);
	}

	public int getFileOffset()
	{
		return this.getSegment().getOffset() + this.getRelOffset();
	}

	public String getFullAddress(String separator)
	{
		StringBuffer result;

		result = new StringBuffer();

		result.append(this.getSegment().getIdString());
		result.append(separator);
		result.append(this.getAddrString());

		return result.toString();
	}

	public String getFullAddress()
	{
		return this.getFullAddress(this.getSegment().getRom().getSegmentSeparator());
	}

	private boolean isSizeChangeable()
	{
		AddrInfo.Type type;

		type = this.getType();
		if (type == AddrInfo.Type.CODE || type == AddrInfo.Type.BYTE || type == AddrInfo.Type.WORD || type == AddrInfo.Type.INT || type == AddrInfo.Type.LONG)
		{
			return false;
		}

		return true;
	}

	protected String toTypicalDASMxEnd(int relofs, String name, int count)
	{
		StringBuffer result;
		boolean doextratab;
		String comment;

		result = new StringBuffer();

		result.append('\t');
		result.append("0x");	//fix format
		result.append(Numbers.toHexString((short)(this.getSegment().convRelOfsToAddr(relofs))));

		doextratab = false;
		if (name==null || name.equals(""))
		{
			doextratab = true;
		}
		else
		{
			result.append('\t');
			result.append(name);
		}

		if (count>0)
		{
			if (doextratab)
			{
				result.append('\t');
			}
			result.append('\t');
			result.append(count);
		}
		comment = this.getComment().toString().trim();
		if (comment!=null && comment.length()>0)
		{
			if (doextratab)
			{
				result.append('\t');
			}
			result.append('\t');
			result.append(';');
			if (comment!=null)
			{
				result.append(' ');
				result.append(comment);
			}
		}

		return result.toString();
	}

	protected String strucToDASMxString()
	{
		StringBuffer result;
		int count;

		result = new StringBuffer();
		count = this.getCount();
		if (count == 0)
		{
			count = 1;
		}
		count *= this.getSize();

		if (count > 0)
		{
			result.append("byte");
		}
		else
		{
			result.append("symbol");
			count = 0;
		}
		result.append(this.toTypicalDASMxEnd(this.getRelOffset(), this.getName().toString(), count));

		return result.toString();
	}

	public String toDASMxString()
	{
		StringBuffer result;
		AddrInfo.Type type;
		int count;

		result = new StringBuffer();
		count = 0;
		type = this.getType();
		if (type == AddrInfo.Type.STRUCTURE)
		{
			// as DASMx can not handle structures, this is done in an separate methods which can be overwritten by subclasses
			return this.strucToDASMxString();
		}
		else if (type == AddrInfo.Type.CODE)
		{
			result.append("code");
		}
		else if (type == AddrInfo.Type.BYTE)
		{
			result.append("byte");
			count = this.getCount();
		}
		else if (type == AddrInfo.Type.WORD)
		{
			result.append("word");
			count = this.getCount();
		}
		else if (type == AddrInfo.Type.STRING)
		{
			result.append("string");
			count = this.getCount();
		}
		else if (type == AddrInfo.Type.VECTOR)
		{
			if (this.getCount() > 0)
			{
				result.append("vectab");
				count = this.getCount();
			}
			else
			{
				result.append("vector");
			}
		}
		else if (type == AddrInfo.Type.ADDRESS)
		{
			if (this.getCount() > 0)
			{
				result.append("addrtab");
				count = this.getCount();
			}
			else
			{
				result.append("word");
			}
		}
		else
		{
			result.append("symbol");
		}

		result.append(this.toTypicalDASMxEnd(this.getRelOffset(), this.getName().toString(), count));

		return result.toString();
	}

	public String createCrossRef()
	{
		if (this.getXRef().isEmpty() && this.getName().toString().equals(""))
		{
			return null;
		}

		StringBuffer result;

		result = new StringBuffer();

		result.append("\"***\";");
		result.append(this.toCrossRef());
		// list references to this addrinfo
		for (AddrInfo addrinfo : this.getXRef())
		{
			result.append(Rom.NEWLINE).append("\"^\";");
			result.append(addrinfo.toCrossRef());
		}
		return result.toString();
	}

	public String toCrossRef()
	{
		StringBuffer result;

		result = new StringBuffer();

		// Name
		result.append("\"");
		result.append(this.getName().toString());
		result.append("\";");
		// Mem address
		result.append("\"");
		result.append(this.getFullAddress());
		result.append("\";");
		// File offset
		result.append("\"");
		result.append(this.getSegment().getRom().getHexPrefix() + Numbers.toHexString(this.getFileOffset()));
		result.append("\";");
		// Segment offset
		result.append("\"");
		result.append(this.getSegment().getRom().getHexPrefix() + Numbers.toHexString(this.getRelOffset()));
		result.append("\";");

		return result.toString();
	}
}
