package maddes.dasm;
/*
(c) Matthias "Maddes" Buecher, http://www.maddes.net/
$Revision: 17 $
$Date: 2007-09-06 18:21:16 +0200 (Do, 06 Sep 2007) $
$Author: maddes $

v1.3
initial version
*/

/*
A class for handling Williams WPC ROMs
*/
public final class BytePattern
{
	private final byte[] pattern;
	private final int postofs;

	public BytePattern(byte[] pattern, int postofs)
	{
		this.pattern = pattern;
		this.postofs = postofs;
	}

	public byte[] getBytePattern()
	{
		return this.pattern;
	}

	public int getPostOffset()
	{
		return this.postofs;
	}
}
